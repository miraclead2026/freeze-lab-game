import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';
import fs from 'node:fs';
import path from 'node:path';

/**
 * 기본 빌드: dist/ (정적 호스팅용 — Cloudflare Pages / Vercel / GitHub Pages)
 *   → 이미지는 public/assets/freeze-lab/ 경로 그대로 로드됩니다.
 * 단일 파일 빌드: `npm run build:single` → dist-single/index.html
 *   → 이미지·폰트·JS·CSS를 모두 인라인해 HTML 파일 하나로 만듭니다. (미리보기/아티팩트 배포용)
 */
const single = process.env.SINGLEFILE === '1';
const ASSET_DIR = path.resolve(__dirname, 'public/assets/freeze-lab');
const MIME: Record<string, string> = { '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.mp3': 'audio/mpeg' };

/** virtual:freeze-lab-assets — 파일명 → URL(또는 data URI) 맵 */
function freezeLabAssets(): Plugin {
  const id = 'virtual:freeze-lab-assets';
  return {
    name: 'freeze-lab-assets',
    resolveId(source) {
      return source === id ? '\0' + id : null;
    },
    load(source) {
      if (source !== '\0' + id) return null;
      const files = fs.readdirSync(ASSET_DIR).filter((f) => MIME[path.extname(f)]);
      if (single) {
        const entries = files.map((f) => {
          const buf = fs.readFileSync(path.join(ASSET_DIR, f));
          return `${JSON.stringify(f)}: ${JSON.stringify(`data:${MIME[path.extname(f)]};base64,${buf.toString('base64')}`)}`;
        });
        return `export default {${entries.join(',')}};`;
      }
      const entries = files.map((f) => `${JSON.stringify(f)}: base + ${JSON.stringify(f)}`);
      return `const base = import.meta.env.BASE_URL + 'assets/freeze-lab/';\nexport default {${entries.join(',')}};`;
    },
  };
}

export default defineConfig({
  base: './',
  plugins: [react(), freezeLabAssets(), ...(single ? [viteSingleFile({ removeViteModuleLoader: true })] : [])],
  build: {
    outDir: single ? 'dist-single' : 'dist',
    assetsInlineLimit: single ? 100_000_000 : 4096,
    cssCodeSplit: false,
    target: 'es2019',
    emptyOutDir: true,
  },
});
