# 배포 가이드 (GitHub Pages)

## 1) 처음 한 번
1. GitHub에서 빈 저장소 생성: `freeze-lab-game` (Public)
2. 이 폴더에서:
   ```bash
   git init -b main
   git add -A
   git commit -m "FREEZE LAB 게임 초기 배포"
   git remote add origin https://github.com/miraclead2026/freeze-lab-game.git
   git push -u origin main
   ```
3. GitHub 저장소 → Settings → Pages → Build and deployment → Source: **GitHub Actions**
4. Actions 탭에서 "Deploy to GitHub Pages"가 초록색으로 끝나면 접속:
   `https://miraclead2026.github.io/freeze-lab-game/`

## 2) 이후 수정
- 코드를 고치고 `git push` 하면 1~2분 뒤 자동으로 반영됩니다. (Actions가 `npm run build` → `dist/` 배포)
- Claude에게 수정을 맡기려면: claude.ai/code 에서 이 저장소를 연결해 두면 Claude가 직접 커밋·푸시할 수 있습니다.

## 3) Actions 없이 쓰는 방법 (가장 단순)
- `npm run build:single` 로 만든 `dist-single/index.html` 한 파일만 저장소 루트에 올리고, Pages Source를 **Deploy from a branch (main / root)** 로 두어도 동작합니다.
- 단, 이 방식은 이미지·폰트가 HTML 안에 인라인되어 파일이 약 4MB이고, 수정할 때마다 파일을 통째로 교체해야 합니다.

## 참고
- 하위 경로(`/freeze-lab-game/`) 배포를 위해 `vite.config.ts`의 `base: './'`(상대 경로)로 설정되어 있습니다. 커스텀 도메인·루트 배포에도 그대로 동작합니다.
- QR 링크: `src/config/gameConfig.ts` → `REWARD_URL`
