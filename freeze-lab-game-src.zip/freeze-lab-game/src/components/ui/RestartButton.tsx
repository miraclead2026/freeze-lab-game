import { useEffect, useState } from 'react';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';

/** 상단 왼쪽 "처음부터" — 한 번 누르면 확인 팝오버, 5초 내 다시 누르면 처음 화면으로 */
export function RestartButton({ onRestart }: { onRestart: () => void }) {
  const t = useT();
  const [ask, setAsk] = useState(false);
  useEffect(() => {
    if (!ask) return;
    const id = setTimeout(() => setAsk(false), 5000);
    return () => clearTimeout(id);
  }, [ask]);
  return (
    <>
      <button
        type="button"
        className="restart-btn"
        onClick={() => {
          sfx.click();
          setAsk((v) => !v);
        }}
        aria-haspopup="dialog"
        aria-expanded={ask}
      >
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 12a8 8 0 1 0 2.5-5.8M4 4v5h5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {t.common.restart}
      </button>
      {ask && (
        <div className="restart-pop" role="dialog" aria-label={t.common.restartConfirm}>
          <span>{t.common.restartConfirm}</span>
          <button
            type="button"
            className="yes"
            onClick={() => {
              sfx.click();
              setAsk(false);
              onRestart();
            }}
          >
            {t.common.restart}
          </button>
          <button type="button" className="no" onClick={() => setAsk(false)}>
            {t.common.restartCancel}
          </button>
        </div>
      )}
    </>
  );
}
