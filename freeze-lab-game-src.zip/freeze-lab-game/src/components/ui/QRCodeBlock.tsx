import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { REWARD_URL } from '../../config/gameConfig';

interface Props {
  /** 브라우저에서 QR을 생성할 URL. 비어 있으면 플레이스홀더 표시 */
  url?: string;
  /** 완성된 QR PNG를 직접 쓰고 싶을 때 (url보다 우선) */
  imageSrc?: string;
  /** 표시 크기(px) */
  size?: number;
  className?: string;
}

/**
 * QR 코드 — 독립 컴포넌트 (흰 배경 + 코너 프레임).
 * - REWARD_URL 상수에 URL을 넣으면 브라우저에서 QR을 생성합니다.
 * - imageSrc에 QR PNG 경로를 넣으면 그 이미지를 그대로 씁니다.
 * - 둘 다 없으면 스캔되지 않는 "QR URL 입력 필요" 플레이스홀더를 표시합니다.
 */
export function QRCodeBlock({ url = REWARD_URL, imageSrc, size = 156, className = '' }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState(false);
  const hasUrl = !!url && !imageSrc;

  useEffect(() => {
    if (!hasUrl || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    QRCode.toCanvas(canvas, url, {
      width: Math.round(size * dpr), // 고해상도 렌더 후 CSS 크기로 축소
      margin: 2, // 여백(quiet zone) 확보
      color: { dark: '#1E2A24', light: '#FFFFFF' },
      errorCorrectionLevel: 'M',
    })
      .then(() => {
        canvas.style.width = `${size}px`;
        canvas.style.height = `${size}px`;
      })
      .catch(() => setError(true));
  }, [url, hasUrl, size]);

  return (
    <div className={`qr-frame ${className}`} style={{ width: size + 24, height: size + 24 }} aria-label={hasUrl ? '룰렛 이벤트 QR 코드' : 'QR 플레이스홀더'}>
      <i className="corner tl" />
      <i className="corner tr" />
      <i className="corner bl" />
      <i className="corner br" />
      {imageSrc ? (
        <img src={imageSrc} alt="QR 코드" style={{ width: size, height: size }} />
      ) : hasUrl && !error ? (
        <canvas ref={canvasRef} style={{ width: size, height: size }} />
      ) : (
        <div className="qr-placeholder" style={{ width: size, height: size }}>
          <span style={{ fontSize: 22 }}>▦</span>
          <span>
            QR URL
            <br />
            입력 필요
          </span>
        </div>
      )}
    </div>
  );
}
