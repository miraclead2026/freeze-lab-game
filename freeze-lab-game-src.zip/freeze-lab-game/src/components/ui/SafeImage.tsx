import { useState, type CSSProperties, type ImgHTMLAttributes } from 'react';
import { ASSETS, assetUrl, type AssetKey } from '../../config/assets';

interface Props extends Omit<ImgHTMLAttributes<HTMLImageElement>, 'src'> {
  asset: AssetKey;
  fallbackStyle?: CSSProperties;
}

/** 이미지 로딩 실패 시 깨진 아이콘 대신 컬러 플레이스홀더를 표시합니다. */
export function SafeImage({ asset, fallbackStyle, className, style, alt, ...rest }: Props) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <span
        role="img"
        aria-label={alt}
        className={`img-fallback ${className ?? ''}`}
        style={{ background: ASSETS[asset].fallbackColor, ...style, ...fallbackStyle }}
      />
    );
  }
  return (
    <img
      {...rest}
      className={className}
      style={style}
      alt={alt ?? ''}
      src={assetUrl(asset)}
      draggable={false}
      onError={() => setFailed(true)}
    />
  );
}
