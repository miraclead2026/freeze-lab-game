import { useEffect, useState } from 'react';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';
import type { SfxFileKey } from '../../config/assets';

/** 실제 게임 화면 위에서 보여줄 예시 동작 (스테이지 좌표) */
export interface BriefingDemo {
  kind: 'tap' | 'drag';
  from: { x: number; y: number };
  to?: { x: number; y: number };
}

interface Props {
  stepNo: string;
  /** 단계 진입 후킹 멘트 — 크게 강조 표시 (예: "얼려라!!") */
  hook: string;
  /** 후킹 멘트와 함께 재생할 녹음 음성 (SFX_FILES 키). 없으면 합성 브리핑음만 */
  hookSound?: SfxFileKey;
  title: string;
  guide: string;
  /** 예시 동작 — 게임 화면의 실제 위치에서 손가락이 시연 */
  demo: BriefingDemo;
  onDone: () => void;
}

/** 확인 버튼이 나타나기까지의 시간(ms) — 예시 동작을 최소 한 번은 보게 */
const CONFIRM_AFTER_MS = 3000;

/**
 * 각 단계 시작 브리핑 — 반투명 오버레이라 실제 게임 화면이 그대로 보이고,
 * 상단 카드에 후킹 멘트·제목·안내, 화면의 실제 위치에서 손가락이 예시 동작을 반복합니다.
 * "확인했어요!" 버튼은 3초 뒤에 나타납니다.
 */
export function StepBriefing({ stepNo, hook, hookSound, title, guide, demo, onDone }: Props) {
  const t = useT();
  const [out, setOut] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (hookSound) sfx.sample(hookSound, { delay: 0.25 });
    else sfx.brief();
    const timer = setTimeout(() => {
      setReady(true);
      sfx.pop();
    }, CONFIRM_AFTER_MS);
    return () => clearTimeout(timer);
  }, [hookSound]);

  const confirm = () => {
    if (out || !ready) return;
    sfx.click();
    setOut(true);
    setTimeout(onDone, 320);
  };

  const { from, to = from } = demo;
  const dx = to.x - from.x;
  const dy = to.y - from.y;

  return (
    <div className={`briefing briefing-live ${out ? 'out' : ''}`} role="dialog" aria-label={`${stepNo} ${title}`}>
      {/* 상단 카드 */}
      <div className="briefing-card">
        <div className="step-no">
          {t.common.step} {stepNo}
        </div>
        <div className="hook" aria-label={hook}>
          <span className={`hook-text ${hook.length > 6 ? 'long' : ''}`}>{hook}</span>
          <span className="hook-line" aria-hidden="true" />
        </div>
        <h2>{title}</h2>
        <p>{guide}</p>
        <button type="button" className={`btn briefing-btn ${ready ? 'show' : ''}`} onClick={confirm} disabled={!ready} aria-hidden={!ready}>
          {t.common.confirm}
        </button>
        {!ready && <span className="briefing-wait" aria-hidden="true" />}
      </div>

      {/* 예시 동작 — 실제 게임 위치 */}
      <div className="demo-layer" aria-hidden="true">
        {demo.kind === 'drag' && (
          <svg className="demo-path" style={{ left: 0, top: 0 }} width="100%" height="100%">
            <line x1={from.x} y1={from.y} x2={to.x} y2={to.y} />
            <circle className="demo-target" cx={to.x} cy={to.y} r="22" />
          </svg>
        )}
        <div className="demo-spot" style={{ left: from.x, top: from.y }} />
        <div
          className={`demo-finger ${demo.kind}`}
          style={{ left: from.x, top: from.y, ['--dx' as string]: `${dx}px`, ['--dy' as string]: `${dy}px` }}
        >
          <svg viewBox="0 0 56 56">
            <path
              d="M23 30V14a4 4 0 0 1 8 0v13l3-1a4 4 0 0 1 5 3l1 1a4 4 0 0 1 5 3v3c0 6-3 10-5 13a5 5 0 0 1-4 2H24a5 5 0 0 1-4-2l-8-11a3.5 3.5 0 0 1 5-5l6 6z"
              fill="#fff"
              stroke="#1E2A24"
              strokeWidth="2"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
