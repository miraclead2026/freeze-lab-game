import { useEffect, useState } from 'react';
import { FingerGuide } from './FingerGuide';
import { sfx } from '../../audio/sfx';

interface Props {
  stepNo: string;
  title: string;
  guide: string;
  finger?: 'tap' | 'drag';
  onDone: () => void;
}

/** 각 단계 시작 시 단계 번호·미션 제목·행동 안내·손가락 가이드를 보여주고, "확인했어요!" 버튼으로 시작합니다. */
export function StepBriefing({ stepNo, title, guide, finger = 'tap', onDone }: Props) {
  const [out, setOut] = useState(false);
  useEffect(() => {
    sfx.brief();
  }, []);
  const confirm = () => {
    if (out) return;
    sfx.click();
    setOut(true);
    setTimeout(onDone, 320);
  };
  return (
    <div className={`briefing ${out ? 'out' : ''}`} role="dialog" aria-label={`${stepNo} ${title}`}>
      <div className="step-no">STEP {stepNo}</div>
      <h2>{title}</h2>
      <p>{guide}</p>
      <div className="finger-wrap">
        <FingerGuide mode={finger} />
      </div>
      <button type="button" className="btn briefing-btn" onClick={confirm} autoFocus>
        확인했어요!
      </button>
    </div>
  );
}
