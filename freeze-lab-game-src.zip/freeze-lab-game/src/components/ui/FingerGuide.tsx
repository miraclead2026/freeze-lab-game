interface Props {
  mode?: 'tap' | 'drag';
  className?: string;
}

/** 터치/드래그 위치를 알려주는 손가락 애니메이션 (SVG) */
export function FingerGuide({ mode = 'tap', className = '' }: Props) {
  return (
    <div style={{ position: 'relative', width: 56, height: 56 }} className={className} aria-hidden="true">
      {mode === 'tap' && <span className="tap-ring" style={{ left: 0, top: 0 }} />}
      <svg className={`finger ${mode}`} viewBox="0 0 56 56">
        <path
          d="M23 30V14a4 4 0 0 1 8 0v13l3-1a4 4 0 0 1 5 3l1 1a4 4 0 0 1 5 3v3c0 6-3 10-5 13a5 5 0 0 1-4 2H24a5 5 0 0 1-4-2l-8-11a3.5 3.5 0 0 1 5-5l6 6z"
          fill="#fff"
          stroke="#1E2A24"
          strokeWidth="2"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}
