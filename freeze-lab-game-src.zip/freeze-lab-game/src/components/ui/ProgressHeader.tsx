const STEPS = [
  { no: '01', label: 'FREEZE' },
  { no: '02', label: 'SUBLIMATE' },
  { no: '03', label: 'BLEND' },
];

interface Props {
  activeIndex: number; // 0~2, 3 = 전부 완료
  done: [boolean, boolean, boolean];
  progress: number; // 0~1
  progressLabel?: string;
}

/** 상단 진행 상태: 01 FREEZE → 02 SUBLIMATE → 03 BLEND + 현재 미션 진행률 */
export function ProgressHeader({ activeIndex, done, progress, progressLabel }: Props) {
  return (
    <header className="hud">
      <div className="hud-brand">
        <span>
          LIFEMEAL <strong>FREEZE LAB</strong>
        </span>
        <span>RESEARCH MISSION</span>
      </div>
      <div className="steps" role="list" aria-label="미션 진행 단계">
        {STEPS.map((s, i) => {
          const isDone = done[i];
          const isActive = i === activeIndex && !isDone;
          return (
            <span key={s.no} style={{ display: 'contents' }}>
              <span
                role="listitem"
                className={`step-chip ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}
                aria-current={isActive ? 'step' : undefined}
              >
                {isDone ? (
                  <svg className="check" viewBox="0 0 12 12" aria-label="완료">
                    <path d="M2 6.2 4.8 9 10 3.4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : (
                  <span className="num">{s.no}</span>
                )}
                {s.label}
              </span>
              {i < STEPS.length - 1 && (
                <span className="step-arrow" aria-hidden="true">
                  →
                </span>
              )}
            </span>
          );
        })}
      </div>
      <div className="mission-progress" aria-live="polite">
        <span>{progressLabel ?? '미션 진행률'}</span>
        <span className="bar">
          <i style={{ width: `${Math.round(progress * 100)}%` }} />
        </span>
        <span className="pct">{Math.round(progress * 100)}%</span>
      </div>
    </header>
  );
}
