import { useEffect, useState } from 'react';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';

/** 효과음 켜기/끄기 (터치 영역 56px) */
export function MuteButton() {
  const t = useT();
  const [muted, setMuted] = useState(sfx.muted);
  useEffect(() => {
    const l = (m: boolean) => setMuted(m);
    sfx.listeners.add(l);
    return () => {
      sfx.listeners.delete(l);
    };
  }, []);
  return (
    <button
      type="button"
      className={`mute-btn ${muted ? 'off' : ''}`}
      aria-label={muted ? t.common.muteOn : t.common.muteOff}
      aria-pressed={muted}
      onClick={() => sfx.toggle()}
    >
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M4 9.5v5h3.2L12 18.6V5.4L7.2 9.5H4z" fill="currentColor" />
        {muted ? (
          <path d="M15.5 9.5l4 5m0-5l-4 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none" />
        ) : (
          <>
            <path d="M15 9.2a3.6 3.6 0 0 1 0 5.6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none" />
            <path d="M17.6 6.8a7 7 0 0 1 0 10.4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none" />
          </>
        )}
      </svg>
    </button>
  );
}
