import { useEffect } from 'react';
import { TIMING } from '../../config/gameConfig';
import { sfx } from '../../audio/sfx';

interface Props {
  title: string;
  lines: string[];
  onDone: () => void;
  /** 팝업이 사라진 뒤 결과를 볼 수 있는 대기 시간 (기본 1초) */
  holdAfterMs?: number;
}

/** 단계 완료 팝업 — 1.2~1.5초 노출 후 자동으로 다음 단계로 전환 */
export function SuccessPopup({ title, lines, onDone, holdAfterMs = TIMING.resultHold }: Props) {
  useEffect(() => {
    sfx.pop();
    const t = setTimeout(onDone, TIMING.successPopup + holdAfterMs);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <PopupShell title={title} lines={lines} />
  );
}

export function PopupShell({ title, lines }: { title: string; lines: string[] }) {
  return (
    <div className="popup" role="status">
      <svg className="badge" viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill="#E6F4CF" />
        <circle cx="32" cy="32" r="22" fill="#00AF66" />
        <path
          d="M22 33.5 29 40 43 25"
          fill="none"
          stroke="#fff"
          strokeWidth="4.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ strokeDasharray: 40, strokeDashoffset: 40, animation: 'drawCheck 0.5s 0.2s ease forwards' }}
        />
        <style>{`@keyframes drawCheck{to{stroke-dashoffset:0}}`}</style>
      </svg>
      <h3>{title}</h3>
      <p>
        {lines.map((l, i) => (
          <span key={i}>
            {l}
            {i < lines.length - 1 && <br />}
          </span>
        ))}
      </p>
    </div>
  );
}
