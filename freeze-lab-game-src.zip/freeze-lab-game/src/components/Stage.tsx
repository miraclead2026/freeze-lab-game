import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { STAGE } from '../config/gameConfig';

interface StageInfo {
  scale: number;
  /** 클라이언트 좌표 → 스테이지 논리 좌표 */
  toLocal: (clientX: number, clientY: number) => { x: number; y: number };
}

const StageContext = createContext<StageInfo>({ scale: 1, toLocal: (x, y) => ({ x, y }) });
export const useStage = () => useContext(StageContext);

/**
 * 390×844 논리 캔버스를 뷰포트(100dvh)에 맞춰 스케일하고 중앙 정렬합니다.
 * 모바일은 꽉 차게, 태블릿·PC는 세로형 카드로 가운데에 놓입니다.
 */
export function Stage({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const update = () => {
      const vw = window.innerWidth;
      const vh = window.visualViewport?.height ?? window.innerHeight;
      const s = Math.min(vw / STAGE.width, vh / STAGE.height);
      setScale(s);
    };
    update();
    window.addEventListener('resize', update);
    window.visualViewport?.addEventListener('resize', update);
    return () => {
      window.removeEventListener('resize', update);
      window.visualViewport?.removeEventListener('resize', update);
    };
  }, []);

  const toLocal = (clientX: number, clientY: number) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return { x: clientX, y: clientY };
    return { x: (clientX - r.left) / scale, y: (clientY - r.top) / scale };
  };

  return (
    <div className="viewport">
      <div
        ref={ref}
        className="stage"
        style={{ transform: `translate(-50%, -50%) scale(${scale})` }}
      >
        <StageContext.Provider value={{ scale, toLocal }}>{children}</StageContext.Provider>
      </div>
    </div>
  );
}
