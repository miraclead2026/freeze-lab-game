import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { SUBLIMATION, TIMING } from '../../config/gameConfig';
import { assetUrl } from '../../config/assets';
import { INGREDIENT_ROW, LENS, ingredientCenters } from '../../config/layout';
import { useParticles } from '../../particles/ParticleCanvas';
import { useStage } from '../Stage';
import { StepBriefing } from '../ui/StepBriefing';
import { SuccessPopup } from '../ui/SuccessPopup';
import { FingerGuide } from '../ui/FingerGuide';
import { sfx } from '../../audio/sfx';

export type MicroPhase = 'play' | 'complete' | 'zoom';

interface Props {
  phase: MicroPhase;
  reduced: boolean;
  onProgress: (p: number) => void;
  onComplete: () => void;
  onPopupDone: () => void;
}

interface Droplet {
  id: number;
  /** 홈 위치 (스테이지 절대 좌표) */
  hx: number;
  hy: number;
  /** 현재 위치 */
  x: number;
  y: number;
  delay: number;
  dur: number;
  state: 'hidden' | 'idle' | 'drag' | 'return' | 'gone';
  size: number;
}

/** 물방울 8개의 초기 배치 (렌즈 반지름 대비 비율·각도) — 서로 겹치지 않도록 안쪽 4개 + 바깥 4개 */
const SLOTS: { r: number; a: number }[] = [
  { r: 0.36, a: -2.36 },
  { r: 0.36, a: -0.79 },
  { r: 0.36, a: 0.79 },
  { r: 0.36, a: 2.36 },
  { r: 0.72, a: -1.57 },
  { r: 0.72, a: 0 },
  { r: 0.72, a: 1.57 },
  { r: 0.72, a: 3.14 },
];

const R = LENS.d / 2;
/** 이 거리(렌즈 중심 기준)를 넘어 놓으면 승화 */
const OUTSIDE = R + 6;

/** STEP 2 — 수분 승화: 얼어 있는 물방울을 영양 구조 밖으로 드래그해 승화 */
export function MicroscopeStep({ phase, reduced, onProgress, onComplete, onPopupDone }: Props) {
  const particles = useParticles();
  const { toLocal } = useStage();
  const [briefing, setBriefing] = useState(true);
  const [drops, setDrops] = useState<Droplet[]>(() =>
    SLOTS.slice(0, SUBLIMATION.moleculeCount).map((s, i) => {
      const hx = LENS.cx + Math.cos(s.a) * s.r * R;
      const hy = LENS.cy + Math.sin(s.a) * s.r * R;
      return { id: i, hx, hy, x: hx, y: hy, delay: (i * 0.37) % 1.4, dur: 1.3 + ((i * 0.23) % 0.8), state: 'hidden', size: 1 + ((i * 0.17) % 0.3) };
    }),
  );
  const [hintVisible, setHintVisible] = useState(true);
  const dragRef = useRef<{ id: number; pointerId: number; dx: number; dy: number; lastSound: number } | null>(null);
  const completeRef = useRef(false);
  const dropsRef = useRef(drops);
  dropsRef.current = drops;

  const remaining = drops.filter((d) => d.state !== 'gone').length;

  // 순차 등장 (반짝이며)
  useEffect(() => {
    const timers = drops.map((d, i) =>
      setTimeout(() => {
        setDrops((prev) => prev.map((q) => (q.id === d.id ? { ...q, state: 'idle' } : q)));
        sfx.pop();
      }, 300 + i * SUBLIMATION.spawnIntervalMs),
    );
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 완료 감지
  useEffect(() => {
    if (completeRef.current) return;
    const gone = drops.filter((d) => d.state === 'gone').length;
    onProgress(gone / SUBLIMATION.moleculeCount);
    if (gone >= SUBLIMATION.moleculeCount) {
      completeRef.current = true;
      particles.emit('vapor', { x: LENS.cx, y: LENS.cy - 60, count: reduced ? 10 : 26 });
      particles.emit('glow', { x: LENS.cx, y: LENS.cy, count: reduced ? 6 : 16 });
      navigator.vibrate?.([20, 40, 30]);
      setTimeout(() => {
        sfx.success();
        onComplete();
      }, 650);
    }
  }, [drops, onComplete, onProgress, particles, reduced]);

  const vaporize = useCallback(
    (d: Droplet) => {
      particles.emit('vapor', { x: d.x, y: d.y, count: reduced ? 8 : 20 });
      particles.emit('ice', { x: d.x, y: d.y, count: reduced ? 3 : 8, power: 0.5, speed: 90 });
      sfx.vaporize();
      navigator.vibrate?.(14);
    },
    [particles, reduced],
  );

  const onPointerDown = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>, id: number) => {
      if (briefing || phase !== 'play' || dragRef.current) return;
      const d = dropsRef.current.find((q) => q.id === id);
      if (!d || d.state !== 'idle') return;
      const p = toLocal(e.clientX, e.clientY);
      dragRef.current = { id, pointerId: e.pointerId, dx: d.x - p.x, dy: d.y - p.y, lastSound: 0 };
      e.currentTarget.setPointerCapture(e.pointerId);
      setHintVisible(false);
      sfx.dropPick();
      navigator.vibrate?.(8);
      setDrops((prev) => prev.map((q) => (q.id === id ? { ...q, state: 'drag' } : q)));
    },
    [briefing, phase, toLocal],
  );

  const onPointerMove = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>) => {
      const drag = dragRef.current;
      if (!drag || e.pointerId !== drag.pointerId) return;
      const p = toLocal(e.clientX, e.clientY);
      const x = p.x + drag.dx;
      const y = p.y + drag.dy;
      const now = performance.now();
      if (now - drag.lastSound > 90) {
        drag.lastSound = now;
        sfx.dropMove();
      }
      setDrops((prev) => prev.map((q) => (q.id === drag.id ? { ...q, x, y } : q)));
    },
    [toLocal],
  );

  const onPointerUp = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>) => {
      const drag = dragRef.current;
      if (!drag || e.pointerId !== drag.pointerId) return;
      dragRef.current = null;
      const d = dropsRef.current.find((q) => q.id === drag.id);
      if (!d) return;
      const dist = Math.hypot(d.x - LENS.cx, d.y - LENS.cy);
      if (dist >= OUTSIDE) {
        // 영양 구조 밖 → 진공에서 바로 수증기로
        vaporize(d);
        setDrops((prev) => prev.map((q) => (q.id === d.id ? { ...q, state: 'gone' } : q)));
      } else {
        // 구조 안에 놓으면 제자리로
        sfx.snapBack();
        setDrops((prev) => prev.map((q) => (q.id === d.id ? { ...q, state: 'return' } : q)));
        setTimeout(() => {
          setDrops((prev) => prev.map((q) => (q.id === d.id ? { ...q, state: 'idle', x: q.hx, y: q.hy } : q)));
        }, 260);
      }
    },
    [vaporize],
  );

  // 줌아웃 전환 목표: STEP 3의 동결건조 브로콜리 카드 위치
  const target = useMemo(() => ingredientCenters(4)[0], []);
  const zooming = phase === 'zoom';
  const zoomDur = reduced ? TIMING.zoomOut * 0.6 : TIMING.zoomOut;
  const targetScale = (INGREDIENT_ROW.tileSize - 14) / LENS.d;
  useEffect(() => {
    if (zooming) sfx.zoomOut();
  }, [zooming]);

  const dragging = drops.find((d) => d.state === 'drag');
  const dragOutside = dragging ? Math.hypot(dragging.x - LENS.cx, dragging.y - LENS.cy) >= OUTSIDE : false;
  const firstIdle = drops.find((d) => d.state === 'idle');

  return (
    <div className="scene">
      <div className="micro-bg" style={{ opacity: zooming ? 0 : 1, transition: zooming ? `opacity ${zoomDur * 0.7}ms ease` : 'none' }} />

      {/* 진공 영역 안내 링 (렌즈 바깥) */}
      {!zooming && (
        <div
          className={`vacuum-ring ${dragging ? 'active' : ''} ${dragOutside ? 'hot' : ''}`}
          style={{ left: LENS.cx, top: LENS.cy, width: LENS.d + 76, height: LENS.d + 76 }}
          aria-hidden="true"
        >
          <span className="vacuum-ring-label">진공 영역 · 여기로 꺼내면 승화</span>
        </div>
      )}

      {/* 현미경 원형 마스크 — 얼어 있는 영양 구조 */}
      <div
        className="lens-mask"
        style={{
          left: LENS.cx,
          top: LENS.cy,
          width: LENS.d,
          height: LENS.d,
          transform: zooming
            ? `translate(-50%, -50%) translate(${target.x - LENS.cx}px, ${target.y - LENS.cy}px) scale(${targetScale})`
            : 'translate(-50%, -50%)',
          transition: zooming ? `transform ${zoomDur}ms cubic-bezier(0.55, 0, 0.3, 1), box-shadow ${zoomDur}ms ease, background ${zoomDur}ms ease` : 'none',
          boxShadow: zooming ? '0 0 0 0 rgba(255,255,255,0), 0 0 0 0 rgba(0,175,102,0)' : undefined,
          background: zooming ? '#ffffff' : undefined,
        }}
      >
        <img
          src={assetUrl('microscopeTissue')}
          alt="얼어 있는 브로콜리 영양 구조"
          style={{ opacity: zooming ? 0 : 1, transition: zooming ? `opacity ${zoomDur * 0.55}ms ${zoomDur * 0.2}ms ease` : 'none' }}
        />
        {/* 얼어 있는 상태를 강조하는 성에 오버레이 */}
        {!zooming && <div className="lens-frost" style={{ backgroundImage: `url(${assetUrl('frostTexture')})`, opacity: 0.55 - (1 - remaining / SUBLIMATION.moleculeCount) * 0.4 }} />}
        <img
          src={assetUrl('fdBroccoli')}
          alt=""
          aria-hidden="true"
          style={{
            width: '84%',
            height: '84%',
            objectFit: 'contain',
            opacity: zooming ? 1 : 0,
            transition: zooming ? `opacity ${zoomDur * 0.5}ms ${zoomDur * 0.35}ms ease` : 'none',
          }}
        />
        <div className="lens-ring" style={{ opacity: zooming ? 0 : 1, transition: `opacity ${zoomDur * 0.5}ms ease` }} />
        <div className="lens-glare" style={{ opacity: zooming ? 0 : 1, transition: `opacity ${zoomDur * 0.5}ms ease` }} />
      </div>

      {/* 얼어 있는 물방울 (렌즈 밖으로 나갈 수 있도록 마스크 바깥 레이어) */}
      {!zooming &&
        drops.map((d) => {
          if (d.state === 'hidden' || d.state === 'gone') return null;
          const isDrag = d.state === 'drag';
          const outside = isDrag && Math.hypot(d.x - LENS.cx, d.y - LENS.cy) >= OUTSIDE;
          return (
            <button
              key={d.id}
              type="button"
              className={`droplet-btn ${isDrag ? 'dragging' : ''} ${outside ? 'outside' : ''} ${d.state === 'return' ? 'returning' : ''}`}
              aria-label="얼어 있는 물방울 — 영양 구조 밖으로 드래그"
              disabled={briefing || phase !== 'play' || d.state === 'return'}
              onPointerDown={(e) => onPointerDown(e, d.id)}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              style={{
                left: d.state === 'return' ? d.hx : d.x,
                top: d.state === 'return' ? d.hy : d.y,
                transform: `translate(-50%, -50%) scale(${d.size * (isDrag ? 1.25 : 1)})`,
                transition: d.state === 'return' ? 'left 0.25s ease, top 0.25s ease, transform 0.25s ease' : 'transform 0.15s ease',
                animation: d.state === 'idle' ? 'fadeIn 0.4s ease both' : 'none',
              }}
            >
              <DropletSvg delay={d.delay} dur={d.dur} active={isDrag} hot={outside} />
            </button>
          );
        })}

      {!briefing && hintVisible && firstIdle && phase === 'play' && (
        <div className="tap-hint" style={{ left: firstIdle.x - 10, top: firstIdle.y - 6, zIndex: 30 }}>
          <FingerGuide mode="drag" />
        </div>
      )}

      {phase === 'play' && !briefing && (
        <div className="step-copy">
          <div className="kicker">STEP 02. SUBLIMATE</div>
          <h1>얼어 있는 수분을 꺼내주세요</h1>
          <p>
            영양 구조 속 얼어 있는 물방울을
            <br />
            밖으로 끌어다 놓아 승화시켜 주세요!
          </p>
        </div>
      )}

      {!zooming && (
        <>
          <div className="vacuum-tag" style={{ left: 20, top: LENS.cy - LENS.d / 2 - 44 }}>
            <i /> VACUUM ON
          </div>
          <div className="frozen-tag" style={{ right: 20, top: LENS.cy - LENS.d / 2 - 44 }}>
            ❄ 영양 구조 · 동결 상태 -40℃
          </div>
          <div className="counter-panel" aria-live="polite">
            <div>
              <div className="label">남은 물방울</div>
              <div className="value">
                <b>{remaining}</b>개
              </div>
            </div>
            <div className="dots" aria-hidden="true">
              {drops.map((d) => (
                <i key={d.id} className={d.state === 'gone' ? 'gone' : ''} />
              ))}
            </div>
          </div>
        </>
      )}

      {briefing && (
        <StepBriefing
          stepNo="02"
          title="얼어 있는 수분을 꺼내주세요"
          guide={'영양 구조 속 물방울을 터치한 채로\n바깥 진공 영역까지 끌어다 놓으면 증발합니다!'}
          finger="drag"
          onDone={() => setBriefing(false)}
        />
      )}

      {phase === 'complete' && (
        <SuccessPopup title="2단계 완료!" lines={['얼어 있던 수분이 승화되어', '원물의 좋은 것만 남았습니다.']} onDone={onPopupDone} />
      )}
    </div>
  );
}

/** 누가 봐도 물인 물방울 — 얼어 있는 느낌의 결정 하이라이트 포함 */
function DropletSvg({ delay, dur, active, hot }: { delay: number; dur: number; active: boolean; hot: boolean }) {
  const style = { ['--delay' as string]: `${delay}s`, ['--dur' as string]: `${dur}s` };
  return (
    <svg className="droplet-svg" viewBox="0 0 64 72" style={style} aria-hidden="true">
      <defs>
        <linearGradient id="dropGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#CFEBFF" />
          <stop offset="55%" stopColor="#5DB4F0" />
          <stop offset="100%" stopColor="#2A7FD1" />
        </linearGradient>
        <radialGradient id="dropShine" cx="35%" cy="30%" r="45%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
      </defs>
      <g className={`droplet-inner ${active ? 'active' : ''}`} style={style}>
        {/* 물방울 본체 */}
        <path
          d="M32 4 C32 4 12 30 12 44 a20 20 0 0 0 40 0 C52 30 32 4 32 4 Z"
          fill="url(#dropGrad)"
          stroke={hot ? '#FFFFFF' : '#2F7FC9'}
          strokeWidth={hot ? 3 : 1.6}
        />
        <path d="M32 4 C32 4 12 30 12 44 a20 20 0 0 0 40 0 C52 30 32 4 32 4 Z" fill="url(#dropShine)" />
        {/* 하이라이트 */}
        <ellipse cx="24" cy="40" rx="4" ry="8" fill="#ffffff" opacity="0.85" transform="rotate(-18 24 40)" />
        {/* 얼음 결정 (동결 상태) */}
        <g stroke="#ffffff" strokeWidth="1.6" strokeLinecap="round" opacity="0.9">
          <path d="M38 46 v12 M32 52 h12 M34 48 l8 8 M42 48 l-8 8" />
        </g>
      </g>
      <g className="molecule-spark" style={style}>
        <path d="M54 8 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" fill="#ffffff" />
        <path d="M8 22 l1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5z" fill="#ffffff" />
      </g>
    </svg>
  );
}
