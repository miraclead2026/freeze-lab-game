import { useEffect, useState, type ReactNode } from 'react';
import { SafeImage } from '../ui/SafeImage';
import { FINAL_PACK } from './GrinderStep';
import { useParticles } from '../../particles/ParticleCanvas';
import { sfx } from '../../audio/sfx';

interface Props {
  reduced: boolean;
  onDone: () => void;
}

/** 문장 목록 — [ ] 안은 강조 */
export const STORY_LINES = ['원물을 [동결] 하고', '동결된 채로 [수분만 승화] 하고', '[가루]로 만들어'] as const;
export const STORY_FINAL = ['영양을 유지시킨', '[닥터샐러드]가 완성되었습니다'] as const;

/** "[강조]" 마크업을 강조 span으로 변환 */
export function emphasize(text: string): ReactNode[] {
  return text.split(/(\[[^\]]+\])/).map((part, i) =>
    part.startsWith('[') && part.endsWith(']') ? (
      <em key={i} className="story-em">
        {part.slice(1, -1)}
      </em>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

/**
 * MISSION STORY — 완성 화면으로 넘어가기 전, 문장이 하나씩 올라오며 동결건조 과정을 정리합니다.
 * 타이밍: 0.4s → 1.6s → 2.8s → (최종) 4.3s → 1.9s 유지 → 완료 화면
 */
export function StoryScreen({ reduced, onDone }: Props) {
  const particles = useParticles();
  const [shown, setShown] = useState(0); // 보이는 줄 수 (1~3), 4 = 최종 문장
  const k = reduced ? 0.7 : 1;

  useEffect(() => {
    const at = [400, 1600, 2800, 4300].map((t) => t * k);
    const timers = at.map((t, i) =>
      setTimeout(() => {
        setShown(i + 1);
        if (i < 3) sfx.pop();
        else {
          sfx.success();
          particles.emit('glow', { x: FINAL_PACK.cx, y: FINAL_PACK.cy, count: reduced ? 6 : 18 });
          particles.emit('check', { x: FINAL_PACK.cx, y: FINAL_PACK.cy + 40, count: reduced ? 3 : 8 });
        }
      }, t),
    );
    const end = setTimeout(onDone, (4300 + 1900) * k);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(end);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="story fade-in" role="status" aria-live="polite">
      {/* STEP 3에서 확대된 위치 그대로 이어지는 닥터샐러드 */}
      <div className="story-pack" style={{ left: FINAL_PACK.cx, top: FINAL_PACK.cy - 30 }}>
        <div className="halo" aria-hidden="true" />
        <SafeImage asset="doctorSaladPack" alt="완성된 닥터샐러드" />
      </div>

      <div className="story-lines">
        {STORY_LINES.map((line, i) => (
          <p key={line} className={`story-line ${shown > i ? 'show' : ''} ${shown >= 4 ? 'dim' : ''}`}>
            {emphasize(line)}
          </p>
        ))}
        <p className={`story-final ${shown >= 4 ? 'show' : ''}`}>
          {emphasize(STORY_FINAL[0])}
          <br />
          {emphasize(STORY_FINAL[1])}
        </p>
      </div>
    </div>
  );
}
