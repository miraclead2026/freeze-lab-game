import { useEffect, useMemo, useState } from 'react';
import { assetUrl, type AssetKey } from '../../config/assets';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';

interface Props {
  reduced: boolean;
  onStart: () => void;
}

/**
 * PROLOGUE — "연구 시작하기" 직후. 원물이 눈처럼 내리는 배경 위로 연구 노트 문장이 한 줄씩 올라오고,
 * 마지막에 "동결건조 START" 버튼이 나타납니다. (브랜드·동결건조를 모르는 고객에게 게임의 목적을 소구)
 */
/** 4번째 줄(질문)이 강조 */
const BIG_LINE = 3;
const LINE_AT = [500, 1700, 2900, 4300, 5900, 7400];
const BUTTON_AT = 8600;

const FLAKE_ASSETS: AssetKey[] = ['broccoliFresh', 'fdBroccoli', 'fdCarrot', 'fdBeet', 'fdKale'];
const FLAKE_COUNT = 22;

interface Flake {
  asset: AssetKey;
  left: number; // %
  size: number; // px
  dur: number; // s
  delay: number; // s (음수: 마운트 시 이미 떨어지는 중)
  sway: number; // px
  rot: number; // deg
}

export function PrologueScreen({ reduced, onStart }: Props) {
  const t = useT();
  const LINES = t.prologue.lines;
  const [shown, setShown] = useState(0);
  const [ready, setReady] = useState(false);
  const k = reduced ? 0.6 : 1;

  const flakes = useMemo<Flake[]>(
    () =>
      Array.from({ length: FLAKE_COUNT }, (_, i) => ({
        asset: FLAKE_ASSETS[i % FLAKE_ASSETS.length],
        left: (i * 37 + 11) % 100,
        size: 26 + ((i * 13) % 34),
        dur: 7 + ((i * 7) % 6),
        delay: -((i * 5) % 12),
        sway: 14 + ((i * 9) % 26),
        rot: ((i * 53) % 360) - 180,
      })),
    [],
  );

  useEffect(() => {
    const timers = LINE_AT.map((t, i) =>
      setTimeout(() => {
        setShown(i + 1);
        sfx.pop();
      }, t * k),
    );
    const b = setTimeout(() => {
      setReady(true);
      sfx.rise();
    }, BUTTON_AT * k);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(b);
    };
  }, [k]);

  /** 문장이 다 나오기 전에 화면을 누르면 전부 보여주고 바로 버튼 표시 */
  const skip = () => {
    if (ready) return;
    setShown(LINES.length);
    setReady(true);
  };
  const start = () => {
    sfx.click();
    onStart();
  };

  return (
    <div className="prologue fade-in" onPointerDown={skip}>
      {/* 원물 눈송이 레이어 — 문장이 나오기 시작하면 살짝 흐려짐 */}
      <div className={`flakes ${shown > 0 ? 'dim' : ''}`} aria-hidden="true">
        {flakes.map((f, i) => (
          <img
            key={i}
            className="flake"
            src={assetUrl(f.asset)}
            alt=""
            style={{
              left: `${f.left}%`,
              width: f.size,
              height: f.size,
              animationDuration: `${f.dur}s, ${f.dur * 0.55}s`,
              animationDelay: `${f.delay}s, ${f.delay}s`,
              ['--sway' as string]: `${f.sway}px`,
              ['--rot' as string]: `${f.rot}deg`,
            }}
          />
        ))}
      </div>

      <div className="prologue-kicker">FREEZE LAB · RESEARCH NOTE</div>

      <div className="prologue-lines" role="status" aria-live="polite">
        {LINES.map((text, i) => (
          <p key={text} className={`prologue-line ${i === BIG_LINE ? 'big' : ''} ${shown > i ? 'show' : ''}`}>
            {text}
          </p>
        ))}
      </div>

      <button type="button" className={`btn prologue-btn ${ready ? 'show' : ''}`} onClick={start} disabled={!ready}>
        {t.prologue.start}
      </button>
    </div>
  );
}
