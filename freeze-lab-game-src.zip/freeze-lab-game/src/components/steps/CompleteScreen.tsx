import { useEffect, useState } from 'react';
import { useParticles } from '../../particles/ParticleCanvas';
import { SafeImage } from '../ui/SafeImage';
import { QRCodeBlock } from '../ui/QRCodeBlock';
import { PACK_LINEUP } from '../../config/assets';
import { FINAL_PACK } from './GrinderStep';
import { REWARD_URL, STAGE } from '../../config/gameConfig';
import { IS_KIOSK } from '../../config/mode';
import { useT } from '../../i18n';
import { sfx } from '../../audio/sfx';

interface Props {
  reduced: boolean;
  onRestart: () => void;
}

/** 라인업 슬롯 (5종) — REWARD 1 카드 안쪽, 중앙 슬롯이 닥터샐러드 */
const LINE = { y: 202, h: 96, slotW: 58, gap: 8 } as const;
const slotX = (i: number) => (STAGE.width - (LINE.slotW * 5 + LINE.gap * 4)) / 2 + i * (LINE.slotW + LINE.gap) + LINE.slotW / 2;

/**
 * MISSION COMPLETE — 현장 터치 모니터용 최종 화면.
 * 고객이 순서대로 세 가지를 알게 한다 (카드가 착·착·착 등장):
 *   REWARD 1  낱포 1개를 받아가세요!            (확정)
 *   REWARD 2  QR 찍으면 최대 5개 더!            (본인 폰으로 QR 스캔 → 룰렛. 화면 내 이동 버튼 없음)
 *   REWARD 3  인스타그램 팔로우하면 동결건조 연구원증 발급
 */
export function CompleteScreen({ reduced, onRestart }: Props) {
  const t = useT();
  const c = t.complete;
  const particles = useParticles();
  const [stage, setStage] = useState<0 | 1 | 2 | 3>(0); // 0 낱포 도착, 1 REWARD1, 2 REWARD2(QR), 3 REWARD3

  useEffect(() => {
    const { cx, cy } = FINAL_PACK;
    sfx.complete();
    particles.emit('confetti', { x: cx, y: cy + 40, count: reduced ? 24 : 80 });
    particles.emit('check', { x: cx, y: cy, count: reduced ? 4 : 10 });
    navigator.vibrate?.([30, 50, 30, 50, 60]);

    const k = reduced ? 0.6 : 1;
    const t1 = setTimeout(() => {
      setStage(1);
      sfx.pop();
    }, 1200 * k);
    const pops = [0, 1, 2, 3].map((i) => setTimeout(() => sfx.pop(), 1200 * k + 420 + i * 120));
    // QR 카드 — 효과음과 함께 등장 → 시선을 QR로 (QR 위에는 파티클 없음)
    const t2 = setTimeout(() => {
      setStage(2);
      sfx.rise();
      particles.emit('glow', { x: STAGE.width / 2, y: 120, count: reduced ? 3 : 8 });
    }, 2400 * k);
    const t3 = setTimeout(() => {
      setStage(3);
      sfx.pop();
    }, 3400 * k);
    return () => {
      [t1, t2, t3, ...pops].forEach(clearTimeout);
    };
  }, [particles, reduced]);

  const restart = () => {
    sfx.click();
    onRestart();
  };

  // 라인업 순서: 데일리 · 영양식 · [닥터샐러드] · 발효건강식 · 프로틴골드 (닥터샐러드 중앙)
  const order = [PACK_LINEUP[1], PACK_LINEUP[2], PACK_LINEUP[0], PACK_LINEUP[3], PACK_LINEUP[4]];

  return (
    <div className="complete fade-in-slow">
      {/* 헤드라인 */}
      <div className="complete-head">
        <div className="title">{c.kicker}</div>
        <h1>{c.title}</h1>
      </div>

      {/* ── REWARD 1 · 낱포 1개 확정 ── */}
      <section className={`rw-card rw1 ${stage >= 1 ? 'show' : ''}`} aria-label="보상 1 낱포 1개">
        <div className="rw-eyebrow">
          <span className="rw-no">{c.reward} 1</span>
          <span className="rw-tag confirmed">
            <svg viewBox="0 0 12 12" aria-hidden="true">
              <path d="M2 6.2 4.8 9 10 3.4" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            {c.confirmed}
          </span>
        </div>
        <h2 className="rw-head">{c.r1Head}</h2>
        <p className="rw-sub">{c.r1Sub}</p>
      </section>

      {/* 낱포 라인업 (별도 레이어 — 닥터샐러드가 화면 중앙에서 슬롯으로 날아감) */}
      <div className="lineup" aria-label="라이프밀 낱포 5종">
        {order.map((p, i) => {
          const isDs = p.key === 'doctorSaladPack';
          const x = slotX(i);
          const toY = LINE.y + LINE.h / 2;
          const shown = isDs || stage >= 1;
          const sideDelay = isDs ? 0 : (i < 2 ? 1 - i : i - 3) * 0.12 + 0.35;
          return (
            <div
              key={p.key}
              className={`lineup-item ${isDs ? 'ds' : ''} ${shown ? 'show' : ''}`}
              style={{
                left: x,
                top: toY,
                width: LINE.slotW,
                height: LINE.h,
                transform: isDs
                  ? stage === 0
                    ? `translate(-50%, -50%) translate(${FINAL_PACK.cx - x}px, ${FINAL_PACK.cy - toY}px) scale(${236 / LINE.h})`
                    : 'translate(-50%, -50%) scale(1)'
                  : shown
                    ? 'translate(-50%, -50%) translateY(0) scale(1)'
                    : 'translate(-50%, -50%) translateY(30px) scale(0.8)',
                opacity: shown ? 1 : 0,
                transition: isDs
                  ? `transform ${reduced ? 0.5 : 0.8}s cubic-bezier(0.3, 0, 0.2, 1)`
                  : `transform 0.5s ${sideDelay}s cubic-bezier(0.2, 0.9, 0.3, 1.2), opacity 0.35s ${sideDelay}s ease`,
                zIndex: isDs ? 3 : 2,
              }}
            >
              <SafeImage asset={p.key} alt={c.packs[p.key as keyof typeof c.packs]} />
              <span className={`lineup-label ${stage >= 1 ? 'show' : ''}`}>{c.packs[p.key as keyof typeof c.packs]}</span>
            </div>
          );
        })}
      </div>

      {/* ── REWARD 2 · 최대 5개 더 — 키오스크: QR(본인 폰으로 스캔) / 모바일: 혜택 받기 버튼 ── */}
      {IS_KIOSK ? (
        <section className={`rw-card rw2 ${stage >= 2 ? 'show' : ''}`} aria-label="보상 2 QR 룰렛">
          <div className={`qr-wrap ${stage >= 2 ? 'show' : ''}`}>
            <QRCodeBlock size={128} />
            <span className="qr-hint">{c.qrHint}</span>
          </div>
          <div className="rw2-side">
            <div className="rw-eyebrow">
              <span className="rw-no">{c.reward} 2</span>
              <span className="rw-tag">{c.rouletteTag}</span>
            </div>
            <h2 className="rw-head">
              {c.r2HeadKioskA}
              <br />
              <b>{c.r2Max}</b> {c.r2HeadKioskB}
            </h2>
            <ol className="rw-steps">
              {c.r2StepsKiosk.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ol>
          </div>
        </section>
      ) : (
        <section className={`rw-card rw2 rw2-mobile ${stage >= 2 ? 'show' : ''}`} aria-label="보상 2 룰렛">
          <div className="rw-eyebrow">
            <span className="rw-no">{c.reward} 2</span>
            <span className="rw-tag">{c.rouletteTag}</span>
          </div>
          <h2 className="rw-head">
            {c.r2HeadMobile} <b>{c.r2Max}</b> {c.r2More}
          </h2>
          <ol className="rw-steps rw-steps-row">
            {c.r2StepsMobile.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ol>
          <a
            className={`btn reward-btn ${stage >= 2 ? 'show' : ''}`}
            href={REWARD_URL || '#'}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => sfx.click()}
            aria-disabled={!REWARD_URL}
          >
            {c.rewardBtn}
            <svg viewBox="0 0 20 20" aria-hidden="true">
              <path d="M7 4l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        </section>
      )}

      {/* ── REWARD 3 · 인스타그램 팔로우 → 연구원증 (가지고 있는 동안 혜택이 계속되는 멤버십 카드) ── */}
      <section className={`rw-card rw3 ${stage >= 3 ? 'show' : ''}`} aria-label="보상 3 연구원증">
        <div className="rw3-top">
          <div className="rw3-card-img">
            <SafeImage asset="researcherIdCard" alt="FREEZE LAB 연구원증" />
          </div>
          <div className="rw3-text">
            <div className="rw-eyebrow">
              <span className="rw-no">{c.reward} 3</span>
              <span className="rw-tag">{c.instaTag}</span>
            </div>
            <h2 className="rw-head">
              {c.r3HeadA}
              <br />
              <b>{c.r3HeadB}</b> {c.r3HeadC}
            </h2>
            <p className="rw-sub">{c.r3Sub}</p>
          </div>
        </div>
        <div className="rw-perks">
          <div className="rw-perks-title">
            <span className="rw-perks-eyebrow">{c.perksEyebrow}</span>
            {c.perksTitle}
          </div>
          <ul>
            {c.perks.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        </div>
      </section>

      <button type="button" className={`restart-link ${stage >= 3 ? 'show' : ''}`} onClick={restart}>
        {c.restart}
      </button>
    </div>
  );
}
