import { useEffect, useState } from 'react';
import { useParticles } from '../../particles/ParticleCanvas';
import { SafeImage } from '../ui/SafeImage';
import { QRCodeBlock } from '../ui/QRCodeBlock';
import { PACK_LINEUP } from '../../config/assets';
import { REWARD_URL } from '../../config/gameConfig';
import { FINAL_PACK } from './GrinderStep';
import { sfx } from '../../audio/sfx';

interface Props {
  reduced: boolean;
  onRestart: () => void;
}

/** 라인업 슬롯 (5종) — 중앙 슬롯이 닥터샐러드 */
const LINE = { y: 206, h: 112, slotW: 62, gap: 6 } as const;
const slotX = (i: number) => (390 - (LINE.slotW * 5 + LINE.gap * 4)) / 2 + i * (LINE.slotW + LINE.gap) + LINE.slotW / 2;

/**
 * MISSION COMPLETE — 목적: 게임을 끝낸 고객이 QR을 찍고 룰렛 이벤트(카카오 로그인)로 넘어가게 하기.
 * 구조: 헤드라인(낱포 1포 확정 → 룰렛으로 최대 5포) → 확정 배지 → 낱포 5종 라인업 → QR(주인공) + "QR 찍고 룰렛 돌리기"
 *       → 룰렛 돌리러 가기 버튼(본인 폰 플레이용) → 면허증 3단계 칩 → 보조 안내 → 다시 하기(작게)
 */
export function CompleteScreen({ reduced, onRestart }: Props) {
  const particles = useParticles();
  const [stage, setStage] = useState<0 | 1 | 2 | 3>(0); // 0 등장, 1 라인업, 2 본문, 3 QR

  useEffect(() => {
    const { cx, cy } = FINAL_PACK;
    sfx.complete();
    particles.emit('confetti', { x: cx, y: cy + 40, count: reduced ? 24 : 80 });
    particles.emit('check', { x: cx, y: cy, count: reduced ? 4 : 10 });
    navigator.vibrate?.([30, 50, 30, 50, 60]);

    const k = reduced ? 0.6 : 1;
    const t1 = setTimeout(() => setStage(1), 1300 * k);
    const pops = [0, 1, 2, 3].map((i) => setTimeout(() => sfx.pop(), 1300 * k + 380 + i * 130));
    const t2 = setTimeout(() => setStage(2), 2300 * k);
    // QR은 본문보다 0.5초 뒤에 효과음과 함께 등장 → 시선을 QR로
    const t3 = setTimeout(() => {
      setStage(3);
      sfx.rise();
      // QR 위에는 파티클을 뿌리지 않음 (스캔 방해 방지) — 배지 근처에만
      particles.emit('glow', { x: 195, y: 180, count: reduced ? 3 : 8 });
    }, 2300 * k + 500);
    return () => {
      [t1, t2, t3, ...pops].forEach(clearTimeout);
    };
  }, [particles, reduced]);

  const restart = () => {
    sfx.click();
    onRestart();
  };

  // 라인업 순서: 데일리 · 영양식 · [닥터샐러드] · 발효건강식 · 프로틴골드 (닥터샐러드 중앙)
  const order = [PACK_LINEUP[1], PACK_LINEUP[2], PACK_LINEUP[0], PACK_LINEUP[3], PACK_LINEUP[4]];

  return (
    <div className="complete fade-in-slow">
      {/* 헤드라인 */}
      <div className="complete-head">
        <div className="title">MISSION COMPLETE!</div>
        <h1>
          연구 완료! 낱포 1포 확정
          <br />
          <span className="accent">룰렛 돌리고 최대 5포</span>까지 더 받아 가세요
        </h1>
        <p className="sub">카카오 로그인 10초면 끝. 당첨 낱포는 현장에서 바로 받아 가세요</p>
      </div>

      {/* 확정 배지 — 이미 확정된 보상임을 시각적으로 고정 */}
      <div className={`badge-confirmed ${stage >= 1 ? 'show' : ''}`} style={{ top: LINE.y - 34 }}>
        <svg viewBox="0 0 12 12" aria-hidden="true">
          <path d="M2 6.2 4.8 9 10 3.4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        낱포 1포 확정
      </div>

      {/* 낱포 라인업 */}
      <div className="lineup" aria-label="라이프밀 낱포 5종">
        {order.map((p, i) => {
          const isDs = p.key === 'doctorSaladPack';
          const x = slotX(i);
          const toY = LINE.y + LINE.h / 2;
          const shown = isDs || stage >= 1;
          const sideDelay = isDs ? 0 : (i < 2 ? 1 - i : i - 3) * 0.13;
          return (
            <div
              key={p.key}
              className={`lineup-item ${isDs ? 'ds' : ''} ${shown ? 'show' : ''}`}
              style={{
                left: x,
                top: toY,
                width: LINE.slotW,
                height: LINE.h,
                transform: isDs
                  ? stage === 0
                    ? `translate(-50%, -50%) translate(${FINAL_PACK.cx - x}px, ${FINAL_PACK.cy - toY}px) scale(${236 / LINE.h})`
                    : 'translate(-50%, -50%) scale(1)'
                  : shown
                    ? 'translate(-50%, -50%) translateY(0) scale(1)'
                    : 'translate(-50%, -50%) translateY(40px) scale(0.8)',
                opacity: shown ? 1 : 0,
                transition: isDs
                  ? `transform ${reduced ? 0.5 : 0.8}s cubic-bezier(0.3, 0, 0.2, 1)`
                  : `transform 0.55s ${sideDelay}s cubic-bezier(0.2, 0.9, 0.3, 1.2), opacity 0.4s ${sideDelay}s ease`,
                zIndex: isDs ? 3 : 2,
              }}
            >
              <SafeImage asset={p.key} alt={p.label} />
              <span className={`lineup-label ${stage >= 1 ? 'show' : ''}`}>{p.label}</span>
            </div>
          );
        })}
      </div>

      {/* QR — 주인공 */}
      <div className={`cta-card ${stage >= 2 ? 'show' : ''}`}>
        <div className={`qr-wrap ${stage >= 3 ? 'show' : ''}`}>
          <QRCodeBlock size={156} />
        </div>
        <div className="qr-side">
          <div className="qr-label">
            QR 찍고
            <br />
            룰렛 돌리기
          </div>
          <div className="qr-now">지금 찍으면 바로 참여</div>
          <div className="qr-max">
            최대 <b>5포</b>
          </div>
        </div>
      </div>

      {/* 본인 폰으로 플레이한 경우 — 같은 링크로 이동 */}
      <a
        className={`btn roulette-btn ${stage >= 3 ? 'show' : ''}`}
        href={REWARD_URL || '#'}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => sfx.click()}
        aria-disabled={!REWARD_URL}
      >
        룰렛 돌리러 가기
        <svg viewBox="0 0 20 20" aria-hidden="true">
          <path d="M7 4l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </a>

      {/* 면허증 진행 상태 */}
      <div className={`license-steps ${stage >= 2 ? 'show' : ''}`} aria-label="연구원 면허증 발급 진행 상태">
        <span className="chip done">
          <i>01</i> 동결건조 게임 완료 ✓
        </span>
        <span className="chip now">
          <i>02</i> 룰렛 이벤트 <em>← 지금</em>
        </span>
        <span className="chip">
          <i>03</i> 인스타그램 팔로우
        </span>
      </div>
      <p className={`license-note ${stage >= 2 ? 'show' : ''}`}>연구원 면허증 발급까지 1단계 남음</p>

      {/* 보조 안내 */}
      <p className={`helper ${stage >= 2 ? 'show' : ''}`}>원하는 낱포는 5종(라이프밀 데일리 · 영양식 · Dr.샐러드 · 발효건강식 · 프로틴 골드) 중 현장에서 선택</p>

      <button type="button" className={`restart-link ${stage >= 2 ? 'show' : ''}`} onClick={restart}>
        처음부터 다시 하기
      </button>
    </div>
  );
}
