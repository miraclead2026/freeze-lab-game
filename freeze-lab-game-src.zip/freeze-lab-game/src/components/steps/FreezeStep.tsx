import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent } from 'react';
import { FREEZE, TIMING } from '../../config/gameConfig';
import { assetUrl } from '../../config/assets';
import { BROCCOLI_BOX, LENS } from '../../config/layout';
import { useParticles } from '../../particles/ParticleCanvas';
import { useStage } from '../Stage';
import { SafeImage } from '../ui/SafeImage';
import { StepBriefing } from '../ui/StepBriefing';
import { SuccessPopup } from '../ui/SuccessPopup';
import { FingerGuide } from '../ui/FingerGuide';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';

export type FreezePhase = 'play' | 'complete' | 'zoom';

interface Props {
  phase: FreezePhase;
  reduced: boolean;
  onProgress: (p: number) => void;
  onComplete: () => void;
  onPopupDone: () => void;
}

/** STEP 1 — 급속 동결: 화면을 연속 터치해 20℃ → -40℃ */
export function FreezeStep({ phase, reduced, onProgress, onComplete, onPopupDone }: Props) {
  const particles = useParticles();
  const { toLocal } = useStage();
  const t = useT();
  const [briefing, setBriefing] = useState(true);
  const [taps, setTaps] = useState(0);
  const lockRef = useRef(false);
  const tapsRef = useRef(0);
  const [hintVisible, setHintVisible] = useState(true);

  const progress = taps / FREEZE.tapsToComplete;
  const temp = Math.round(FREEZE.startTemp - taps * FREEZE.tempPerTap);
  const done = taps >= FREEZE.tapsToComplete;

  // 진행률에 따라 냉기·백연 지속 방출
  useEffect(() => {
    if (briefing || phase !== 'play') return;
    if (progress <= 0) return;
    const id = setInterval(() => {
      // 브로콜리 윤곽(위쪽·옆면)에서 냉기가 피어오름 — 줄기 쪽에 쌓이지 않도록
      const a = -Math.PI + Math.random() * Math.PI;
      particles.emit('mist', {
        x: BROCCOLI_BOX.cx + Math.cos(a) * (95 + Math.random() * 45),
        y: BROCCOLI_BOX.cy - 20 + Math.sin(a) * (70 + Math.random() * 50),
        count: Math.ceil(1 + progress * 2),
        power: 0.5 + progress * 0.6,
      });
      if (Math.random() < 0.5) {
        particles.emit('mist', { x: BROCCOLI_BOX.cx + (Math.random() - 0.5) * 220, y: BROCCOLI_BOX.cy + 150, count: 1, power: 0.5 + progress * 0.5 });
      }
    }, 150);
    return () => clearInterval(id);
  }, [briefing, phase, progress, particles]);

  const handleTap = useCallback(
    (e: PointerEvent<HTMLButtonElement>) => {
      if (briefing || lockRef.current || phase !== 'play') return;
      if (tapsRef.current >= FREEZE.tapsToComplete) return;
      tapsRef.current += 1;
      const n = tapsRef.current;
      setTaps(n);
      setHintVisible(false);
      onProgress(n / FREEZE.tapsToComplete);
      navigator.vibrate?.(FREEZE.hapticMs);
      const p = n / FREEZE.tapsToComplete;
      sfx.freezeTap(p);
      if (n === 5 || n === 10) sfx.wind();

      const { x, y } = toLocal(e.clientX, e.clientY);
      particles.emit('ice', { x, y, count: 10 + Math.round(p * 8), power: 0.8 + p * 0.5 });
      particles.emit('mist', { x, y: y + 30, count: 2, power: 0.8 });

      if (n >= FREEZE.tapsToComplete) {
        lockRef.current = true; // 입력 잠금 — 중복 실행 방지
        // 마지막 터치: 얼음 결정이 한 번 크게 퍼지는 성공 효과
        particles.emit('ice', { x: BROCCOLI_BOX.cx, y: BROCCOLI_BOX.cy, count: reduced ? 24 : 70, power: 2.2, speed: 320 });
        particles.emit('ice', { x: BROCCOLI_BOX.cx, y: BROCCOLI_BOX.cy, count: reduced ? 12 : 40, power: 1.4, speed: 160 });
        particles.emit('mist', { x: BROCCOLI_BOX.cx, y: BROCCOLI_BOX.cy + 60, count: 10, power: 1.6 });
        navigator.vibrate?.([20, 40, 30]);
        sfx.iceBurst();
        setTimeout(() => {
          sfx.success();
          onComplete();
        }, 650);
      }
    },
    [briefing, phase, onProgress, onComplete, particles, toLocal, reduced],
  );

  // 온도 게이지 위치 (-40 ~ 20 → 0% ~ 100%)
  const gaugeLeft = ((temp - FREEZE.targetTemp) / (FREEZE.startTemp - FREEZE.targetTemp)) * 100;
  const coldRatio = 1 - gaugeLeft / 100;
  const tempColor = `rgb(${Math.round(30 + 20 * (1 - coldRatio))}, ${Math.round(42 + 60 * coldRatio)}, ${Math.round(36 + 180 * coldRatio)})`;

  const zooming = phase === 'zoom';
  const zoomDur = reduced ? TIMING.zoomIn * 0.6 : TIMING.zoomIn;
  useEffect(() => {
    if (zooming) sfx.zoomIn();
  }, [zooming]);

  // 브로콜리 색상 변화: 채도↓ 밝기↑ 청색 계열로
  const broccoliFilter = useMemo(
    () => `saturate(${1 - progress * 0.6}) brightness(${1 + progress * 0.1}) contrast(${1 - progress * 0.06}) hue-rotate(${-progress * 22}deg)`,
    [progress, zooming],
  );

  const frostUrl = assetUrl('frostTexture');
  // CSS 변수(--mask) 안의 상대 URL은 스타일시트 기준으로 해석되므로 절대 URL로 변환합니다.
  const broccoliUrl = new URL(assetUrl('broccoliFresh'), document.baseURI).href;
  const frostTileUrl = new URL(assetUrl('frostTile'), document.baseURI).href;

  return (
    <div className="scene">
      <div className="lab-table" aria-hidden="true" />

      {/* 화면 가장자리 서리 */}
      <div
        className="edge-frost"
        style={{ backgroundImage: `url(${frostUrl})`, opacity: 0.08 + progress * 0.7 }}
        aria-hidden="true"
      />

      {/* 브로콜리 (효과 누적) */}
      <div
        className="broccoli-wrap"
        style={{
          left: BROCCOLI_BOX.cx,
          top: BROCCOLI_BOX.cy,
          transform: `translate(-50%, -50%) scale(${zooming ? (reduced ? 2.6 : 7) : 1})`,
          transition: zooming ? `transform ${zoomDur}ms cubic-bezier(0.6, 0, 0.9, 0.4), filter ${zoomDur}ms ease` : 'transform 0.2s ease',
          filter: zooming ? 'blur(3px)' : 'none',
          opacity: zooming ? 0.9 : 1,
        }}
      >
        <div className="broccoli-shadow" style={{ opacity: zooming ? 0 : 1 }} />
        <SafeImage asset="broccoliFresh" alt="브로콜리" className="broccoli-img" style={{ filter: broccoliFilter }} />
        {/* 브로콜리 형태에 맞춘 성에: (1) 차가운 푸른 기운 (2) 표면 전체에 고르게 퍼지는 얼음 결정 (3) 윤곽을 따라 두꺼워지는 성에 띠 */}
        <div className="frost-mask frost-tint" style={{ ['--mask' as string]: `url(${broccoliUrl})`, opacity: progress * 0.45 }} aria-hidden="true" />
        <div
          className="frost-mask frost-surface"
          style={{ ['--mask' as string]: `url(${broccoliUrl})`, backgroundImage: `url(${frostTileUrl}), url(${frostTileUrl})`, opacity: progress * 0.5 }}
          aria-hidden="true"
        />
        <div className="frost-mask frost-veil" style={{ ['--mask' as string]: `url(${broccoliUrl})`, opacity: progress * 0.14 }} aria-hidden="true" />
        <div
          className="frost-rim"
          style={{ ['--mask' as string]: `url(${broccoliUrl})`, backgroundImage: `url(${frostTileUrl})`, opacity: Math.max(0, progress - 0.2) * 0.85 }}
          aria-hidden="true"
        />
      </div>

      {/* 넓은 터치 영역 */}
      <button
        type="button"
        className="tap-zone"
        aria-label="브로콜리를 터치해 온도를 낮추세요"
        onPointerDown={handleTap}
        disabled={done || phase !== 'play'}
        style={{
          left: BROCCOLI_BOX.cx - 175,
          top: BROCCOLI_BOX.cy - 175,
          width: 350,
          height: 350,
        }}
      />

      {!briefing && hintVisible && phase === 'play' && (
        <div className="tap-hint" style={{ left: BROCCOLI_BOX.cx + 40, top: BROCCOLI_BOX.cy + 20 }}>
          <FingerGuide mode="tap" />
        </div>
      )}

      {/* 화면 문구 */}
      {phase === 'play' && !briefing && (
        <div className="step-copy">
          <div className="kicker">{t.freeze.kicker}</div>
          <h1>{t.freeze.title}</h1>
          <p style={{ whiteSpace: 'pre-line' }}>{t.freeze.guide}</p>
        </div>
      )}

      {/* 온도 표시 */}
      {!zooming && (
        <div className="temp-panel" aria-live="polite">
          <div>
            <div className="label">{t.freeze.tempNow}</div>
            <div className="value" style={{ color: tempColor }}>
              {temp}℃
            </div>
            <div className="label" style={{ marginTop: 4 }}>
              {t.freeze.tempTarget} <b style={{ color: 'var(--ink)' }}>{FREEZE.targetTemp}℃</b>
            </div>
          </div>
          <div className="temp-gauge" role="meter" aria-valuenow={temp} aria-valuemin={FREEZE.targetTemp} aria-valuemax={FREEZE.startTemp}>
            <i className={coldRatio > 0.5 ? 'cold' : ''} style={{ left: `${gaugeLeft}%` }} />
          </div>
          <div className="tap-counter">
            {t.freeze.taps}
            <b>
              {taps}/{FREEZE.tapsToComplete}
            </b>
          </div>
        </div>
      )}

      {/* 현미경 렌즈: 줌인하는 동안 중심에서 커지며 crossfade */}
      <div
        className="lens-mask"
        aria-hidden="true"
        style={{
          left: LENS.cx,
          top: LENS.cy,
          width: LENS.d,
          height: LENS.d,
          transform: `translate(-50%, -50%) scale(${zooming ? 1 : 0.02})`,
          opacity: zooming ? 1 : 0,
          transition: zooming
            ? `transform ${zoomDur}ms cubic-bezier(0.3, 0, 0.2, 1), opacity ${zoomDur * 0.5}ms ${zoomDur * 0.25}ms ease`
            : 'none',
          zIndex: 45,
          pointerEvents: 'none',
        }}
      >
        <img src={assetUrl('microscopeTissue')} alt="" />
        <div className="lens-ring" />
        <div className="lens-glare" />
      </div>

      {briefing && (
        <StepBriefing
          hook={t.freeze.hook}
          stepNo="01"
          title={t.freeze.title}
          guide={t.freeze.guide}
          demo={{ kind: 'tap', from: { x: BROCCOLI_BOX.cx, y: BROCCOLI_BOX.cy + 10 } }}
          onDone={() => setBriefing(false)}
        />
      )}

      {phase === 'complete' && (
        <SuccessPopup title={t.freeze.doneTitle} lines={[...t.freeze.doneLines]} onDone={onPopupDone} />
      )}
    </div>
  );
}
