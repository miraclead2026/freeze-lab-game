import { useT } from '../../i18n';

export function LoadingScreen({ progress }: { progress: number }) {
  const t = useT();
  const pct = Math.round(progress * 100);
  return (
    <div className="loading" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
      <div className="logo">LIFEMEAL FREEZE LAB</div>
      <div className="pct">{pct}%</div>
      <div className="bar">
        <i style={{ width: `${pct}%` }} />
      </div>
      <div className="sub">{t.loading}</div>
    </div>
  );
}
