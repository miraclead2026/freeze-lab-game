import { SafeImage } from '../ui/SafeImage';
import { sfx } from '../../audio/sfx';
import { useLang } from '../../i18n';
import { LANGS } from '../../i18n/strings';

export function IntroScreen({ onStart }: { onStart: () => void }) {
  const { t, lang, setLang } = useLang();
  const start = () => {
    sfx.unlock();
    sfx.click();
    onStart();
  };
  return (
    <div className="intro fade-in">
      {/* 메인 로고: 라이프밀 → 그 아래 Freeze Lab */}
      <div className="intro-logos">
        <SafeImage asset="logoLifemeal" alt="lifemeal" className="logo-main" />
        <SafeImage asset="logoFreezeLab" alt="Freeze Lab — LIFEMEAL by HEMILY" className="logo-sub" />
      </div>

      {/* 배경: 동결건조 연구실 (CSS background) — 브로콜리 히어로는 제거 */}
      <div className="intro-veil" aria-hidden="true" />

      {/* 언어 선택 — 기본 한국어 */}
      <div className="lang-switch" role="group" aria-label={t.intro.langLabel}>
        {LANGS.map((l) => (
          <button
            key={l.code}
            type="button"
            className={`lang-btn ${lang === l.code ? 'on' : ''}`}
            aria-pressed={lang === l.code}
            onClick={() => {
              sfx.click();
              setLang(l.code);
            }}
          >
            {l.label}
          </button>
        ))}
      </div>

      <div className="kicker">{t.intro.kicker}</div>
      <h1>{t.intro.title}</h1>
      <p>
        {t.intro.desc[0]}
        <br />
        {t.intro.desc[1]}
      </p>
      <div className="mission-list" aria-hidden="true">
        <span>01 FREEZE</span>
        <span>02 SUBLIMATE</span>
        <span>03 BLEND</span>
      </div>
      <button className="btn" onClick={start} style={{ width: '100%' }}>
        {t.intro.start}
      </button>
    </div>
  );
}
