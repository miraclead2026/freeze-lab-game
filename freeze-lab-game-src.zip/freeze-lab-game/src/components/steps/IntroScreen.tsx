import { SafeImage } from '../ui/SafeImage';
import { sfx } from '../../audio/sfx';

export function IntroScreen({ onStart }: { onStart: () => void }) {
  const start = () => {
    sfx.unlock();
    sfx.click();
    onStart();
  };
  return (
    <div className="intro fade-in">
      {/* 메인 로고: 라이프밀 → 그 아래 Freeze Lab */}
      <div className="intro-logos">
        <SafeImage asset="logoLifemeal" alt="lifemeal" className="logo-main" />
        <SafeImage asset="logoFreezeLab" alt="Freeze Lab — LIFEMEAL by HEMILY" className="logo-sub" />
      </div>

      <div className="hero-glow" aria-hidden="true" />
      <div className="hero">
        <SafeImage asset="broccoliFresh" alt="신선한 브로콜리" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
      </div>

      <div className="kicker">FREEZE LAB RESEARCH MISSION</div>
      <h1>동결건조 연구 미션</h1>
      <p>
        브로콜리를 얼리고, 수분을 승화시키고,
        <br />
        원물을 분쇄해 닥터샐러드를 완성해 보세요.
      </p>
      <div className="mission-list" aria-hidden="true">
        <span>01 FREEZE</span>
        <span>02 SUBLIMATE</span>
        <span>03 BLEND</span>
      </div>
      <button className="btn" onClick={start} style={{ width: '100%' }}>
        연구 시작하기
      </button>
    </div>
  );
}
