import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { STAGE, BLEND, INGREDIENTS, TIMING, type IngredientId } from '../../config/gameConfig';
import { type AssetKey } from '../../config/assets';
import {
  GRINDER_BLADE,
  GRINDER_BOX,
  GRINDER_DROP_RADIUS,
  GRINDER_INTAKE,
  GRINDER_LIGHT,
  GRINDER_OUTLET,
  INGREDIENT_ROW,
  PACK_MOUTH,
  PACK_POS,
  ingredientCenters,
} from '../../config/layout';
import { useParticles } from '../../particles/ParticleCanvas';
import { useStage } from '../Stage';
import { SafeImage } from '../ui/SafeImage';
import { StepBriefing } from '../ui/StepBriefing';
import { FingerGuide } from '../ui/FingerGuide';
import { sfx } from '../../audio/sfx';
import { useT } from '../../i18n';

export type GrinderPhase = 'enter' | 'play' | 'finish';

interface Props {
  phase: GrinderPhase;
  reduced: boolean;
  onProgress: (p: number) => void;
  onComplete: () => void;
}

const ASSET_OF: Record<IngredientId, AssetKey> = {
  broccoli: 'fdBroccoli',
  carrot: 'fdCarrot',
  beet: 'fdBeet',
  kale: 'fdKale',
};

interface Flyer {
  id: IngredientId;
  x: number;
  y: number;
  scale: number;
  opacity: number;
  mode: 'drag' | 'fly' | 'return';
}

/** 최종 확대 목표 (MISSION COMPLETE 화면의 제품 위치와 맞춤) */
export const FINAL_PACK = { cx: STAGE.width / 2, cy: 300, scale: 236 / PACK_POS.h } as const;

/** STEP 3 — 원물 블렌딩: 원물을 분쇄기로 끌어다 놓아 닥터샐러드 완성 */
export function GrinderStep({ phase, reduced, onProgress, onComplete }: Props) {
  const particles = useParticles();
  const { toLocal } = useStage();
  const t = useT();
  const [briefing, setBriefing] = useState(phase !== 'enter');
  const [doneIds, setDoneIds] = useState<IngredientId[]>([]);
  const [flyer, setFlyer] = useState<Flyer | null>(null);
  const [active, setActive] = useState(false); // 분쇄기 작동 중
  const [shake, setShake] = useState(false);
  const [stopped, setStopped] = useState(false);
  const [sealed, setSealed] = useState(false);
  const [zoomPack, setZoomPack] = useState(false);
  const [hintVisible, setHintVisible] = useState(true);
  const dragRef = useRef<{ id: IngredientId; index: number; pointerId: number; dx: number; dy: number } | null>(null);
  const busyRef = useRef(false);
  const powderCountRef = useRef(0);
  const centers = useMemo(() => ingredientCenters(INGREDIENTS.length), []);

  // 전환이 끝나고 play가 되면 브리핑 시작 + 분쇄기 대기 소리
  useEffect(() => {
    if (phase === 'play') setBriefing(true);
  }, [phase]);
  useEffect(() => {
    if (!briefing && phase === 'play' && !stopped) sfx.grinder(1);
  }, [briefing, phase, stopped]);
  useEffect(() => () => sfx.grinder(0), []);

  const runPowder = useCallback(
    (color: string) => {
      const dur = BLEND.powderDurationMs;
      const start = performance.now();
      sfx.sprinkle();
      const id = setInterval(() => {
        const elapsed = performance.now() - start;
        if (elapsed > dur) {
          clearInterval(id);
          powderCountRef.current += 1;
          if (powderCountRef.current >= INGREDIENTS.length) {
            // 4개 모두 완료 → 분쇄기 정지 → 밀봉 → 제품 확대
            setActive(false);
            setStopped(true);
            sfx.grinder(0);
            particles.emit('glow', { x: PACK_MOUTH.x, y: PACK_MOUTH.y + 60, count: reduced ? 6 : 14 });
            setTimeout(() => {
              setSealed(true);
              sfx.pop();
            }, 350);
            setTimeout(() => {
              setZoomPack(true);
              sfx.rise();
            }, 800);
            setTimeout(onComplete, 800 + (reduced ? TIMING.finalZoom * 0.6 : TIMING.finalZoom) + 100);
          }
          return;
        }
        const intensity = elapsed < 200 ? 0.5 : elapsed > dur - 300 ? 0.4 : 1;
        particles.emit('powder', {
          x: GRINDER_OUTLET.x,
          y: GRINDER_OUTLET.y,
          count: Math.round((reduced ? 3 : 7) * intensity),
          colors: [color, shade(color, -12), shade(color, 14)],
          targetX: PACK_MOUTH.x,
          targetY: PACK_MOUTH.y,
        });
      }, 40);
    },
    [particles, reduced, onComplete],
  );

  /** 투입구 도착 → 분쇄 시작 */
  const ingest = useCallback(
    (ing: (typeof INGREDIENTS)[number]) => {
      setDoneIds((prev) => {
        const next = [...prev, ing.id];
        onProgress(next.length / INGREDIENTS.length);
        return next;
      });
      setActive(true);
      setShake(true);
      setTimeout(() => setShake(false), 450);
      sfx.dropIn();
      sfx.grinder(2);
      navigator.vibrate?.([15, 30, 15]);
      particles.emit('dust', { x: GRINDER_INTAKE.x, y: GRINDER_INTAKE.y + 6, count: reduced ? 4 : 10, color: ing.powder });
      setTimeout(() => runPowder(ing.powder), BLEND.powderDelayMs);
    },
    [onProgress, particles, reduced, runPowder],
  );

  /** 드롭 존 안에 놓았을 때: 투입구로 빨려 들어가는 짧은 애니메이션 */
  const flyInto = useCallback(
    (ing: (typeof INGREDIENTS)[number], from: { x: number; y: number }) => {
      busyRef.current = true;
      const to = GRINDER_INTAKE;
      const start = performance.now();
      const dur = reduced ? 220 : 320;
      const tick = (now: number) => {
        const raw = Math.min(1, (now - start) / dur);
        const t = 1 - Math.pow(1 - raw, 2);
        setFlyer({ id: ing.id, x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t, scale: 1 - raw * 0.85, opacity: raw > 0.85 ? (1 - raw) / 0.15 : 1, mode: 'fly' });
        if (raw < 1) {
          requestAnimationFrame(tick);
          return;
        }
        setFlyer(null);
        busyRef.current = false;
        ingest(ing);
      };
      requestAnimationFrame(tick);
    },
    [ingest, reduced],
  );

  /** 드롭 존 밖에 놓았을 때: 제자리로 */
  const flyBack = useCallback(
    (ing: (typeof INGREDIENTS)[number], from: { x: number; y: number }, index: number) => {
      busyRef.current = true;
      const to = centers[index];
      const start = performance.now();
      const dur = 260;
      sfx.snapBack();
      const tick = (now: number) => {
        const raw = Math.min(1, (now - start) / dur);
        const t = 1 - Math.pow(1 - raw, 3);
        setFlyer({ id: ing.id, x: from.x + (to.x - from.x) * t, y: from.y + (to.y - from.y) * t, scale: 1.15 - raw * 0.15, opacity: 1, mode: 'return' });
        if (raw < 1) {
          requestAnimationFrame(tick);
          return;
        }
        setFlyer(null);
        busyRef.current = false;
      };
      requestAnimationFrame(tick);
    },
    [centers],
  );

  const onPointerDown = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>, ing: (typeof INGREDIENTS)[number], index: number) => {
      if (briefing || phase !== 'play' || dragRef.current || busyRef.current) return;
      if (doneIds.includes(ing.id)) return;
      const p = toLocal(e.clientX, e.clientY);
      const c = centers[index];
      dragRef.current = { id: ing.id, index, pointerId: e.pointerId, dx: c.x - p.x, dy: c.y - p.y };
      e.currentTarget.setPointerCapture(e.pointerId);
      setHintVisible(false);
      sfx.grab();
      navigator.vibrate?.(8);
      setFlyer({ id: ing.id, x: c.x, y: c.y, scale: 1.15, opacity: 1, mode: 'drag' });
    },
    [briefing, phase, doneIds, centers, toLocal],
  );

  const onPointerMove = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>) => {
      const drag = dragRef.current;
      if (!drag || e.pointerId !== drag.pointerId) return;
      const p = toLocal(e.clientX, e.clientY);
      setFlyer((f) => (f && f.mode === 'drag' ? { ...f, x: p.x + drag.dx, y: p.y + drag.dy } : f));
    },
    [toLocal],
  );

  const onPointerUp = useCallback(
    (e: ReactPointerEvent<HTMLButtonElement>) => {
      const drag = dragRef.current;
      if (!drag || e.pointerId !== drag.pointerId) return;
      dragRef.current = null;
      const p = toLocal(e.clientX, e.clientY);
      const pos = { x: p.x + drag.dx, y: p.y + drag.dy };
      const ing = INGREDIENTS[drag.index];
      const dist = Math.hypot(pos.x - GRINDER_INTAKE.x, pos.y - GRINDER_INTAKE.y);
      if (dist <= GRINDER_DROP_RADIUS) flyInto(ing, pos);
      else flyBack(ing, pos, drag.index);
    },
    [toLocal, flyInto, flyBack],
  );

  // 분말이 다 떨어진 뒤 대기 속도로
  useEffect(() => {
    if (!active) return;
    const t = setTimeout(() => {
      setActive(false);
      if (!stopped) sfx.grinder(1);
    }, BLEND.powderDelayMs + BLEND.powderDurationMs + 200);
    return () => clearTimeout(t);
  }, [active, doneIds, stopped]);

  const rpm = stopped ? 0 : active ? BLEND.activeBladeRpm : BLEND.idleBladeRpm;
  const rpmDur = rpm > 0 ? `${60 / rpm}s` : '10s';
  const entering = phase === 'enter';
  const finalDur = reduced ? TIMING.finalZoom * 0.6 : TIMING.finalZoom;
  const count = doneIds.length;
  const firstAvailable = INGREDIENTS.findIndex((i) => !doneIds.includes(i.id));
  const dragging = flyer?.mode === 'drag';
  const overDrop = dragging && flyer ? Math.hypot(flyer.x - GRINDER_INTAKE.x, flyer.y - GRINDER_INTAKE.y) <= GRINDER_DROP_RADIUS : false;

  return (
    <div className={`scene ${entering ? 'fade-in-slow' : ''}`}>
      <div className="lab-bg" />
      <div className="lab-shelf" style={{ top: INGREDIENT_ROW.y - 4 }} />
      <div className="lab-shelf" style={{ top: INGREDIENT_ROW.y + INGREDIENT_ROW.tileSize + 30 }} />

      {/* 드롭 존 표시 (드래그 중) */}
      <div
        className={`drop-zone ${dragging ? 'show' : ''} ${overDrop ? 'over' : ''}`}
        style={{ left: GRINDER_INTAKE.x, top: GRINDER_INTAKE.y, width: GRINDER_DROP_RADIUS * 2, height: GRINDER_DROP_RADIUS * 2 }}
        aria-hidden="true"
      >
        <span>{t.blend.dropHere}</span>
      </div>

      {/* 분쇄기 본체 */}
      <div
        className={`grinder-wrap ${shake ? 'shake' : ''}`}
        style={{ left: GRINDER_BOX.x, top: GRINDER_BOX.y, width: GRINDER_BOX.w, height: GRINDER_BOX.h, opacity: zoomPack ? 0.25 : 1, transition: 'opacity 0.6s ease' }}
      >
        <div
          className={`blade ${stopped ? 'blade-stop' : ''}`}
          style={{
            left: GRINDER_BLADE.x - GRINDER_BOX.x,
            top: GRINDER_BLADE.y - GRINDER_BOX.y,
            width: 92,
            height: 92,
            transform: 'translate(-50%, -50%) scaleY(0.32)',
            ['--rpm-dur' as string]: rpmDur,
          }}
        >
          <BladeSvg active={active} />
        </div>
        <SafeImage asset="grinderBase" alt="분쇄기" className="grinder-img" />
        <div
          className={`status-light ${active ? 'on' : ''}`}
          style={{ left: GRINDER_LIGHT.x - GRINDER_BOX.x, top: GRINDER_LIGHT.y - GRINDER_BOX.y, opacity: stopped ? 0.2 : undefined }}
        />
      </div>

      {/* 닥터샐러드 낱포 — 윗부분이 뜯어진 상태로 분말을 받고, 완료 시 밀봉된 완제품으로 */}
      <div
        className="pack-wrap"
        style={{
          left: PACK_POS.x,
          top: PACK_POS.y,
          width: PACK_POS.w,
          height: PACK_POS.h,
          zIndex: zoomPack ? 50 : 8,
          transform: zoomPack
            ? `translate(${FINAL_PACK.cx - (PACK_POS.x + PACK_POS.w / 2)}px, ${FINAL_PACK.cy - (PACK_POS.y + PACK_POS.h / 2)}px) scale(${FINAL_PACK.scale})`
            : 'none',
          transformOrigin: 'center center',
          transition: zoomPack ? `transform ${finalDur}ms cubic-bezier(0.3, 0, 0.2, 1)` : 'none',
        }}
      >
        <div className="pack-shadow" style={{ opacity: zoomPack ? 0 : 1 }} />
        <SafeImage
          asset="doctorSaladPackOpen"
          alt="닥터샐러드 낱포 (입구 개봉)"
          style={{ position: 'absolute', left: 0, bottom: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center bottom', opacity: sealed ? 0 : 1, transition: 'opacity 0.5s ease' }}
        />
        <SafeImage
          asset="doctorSaladPack"
          alt="닥터샐러드 낱포"
          style={{ position: 'absolute', left: 0, bottom: 0, width: '100%', height: '114%', objectFit: 'contain', objectPosition: 'center bottom', opacity: sealed ? 1 : 0, transition: 'opacity 0.5s ease' }}
        />
      </div>

      {/* 원물 4종 — 끌어서 분쇄기로 */}
      {INGREDIENTS.map((ing, i) => {
        const c = centers[i];
        const isDone = doneIds.includes(ing.id);
        const isMoving = flyer?.id === ing.id;
        return (
          <button
            key={ing.id}
            type="button"
            className={`ingredient ${isDone ? 'done' : ''} ${isMoving ? 'flying' : ''}`}
            style={{ position: 'absolute', left: c.x - INGREDIENT_ROW.tileSize / 2, top: INGREDIENT_ROW.y, zIndex: 10, opacity: zoomPack ? 0 : 1, transition: 'opacity 0.5s ease', touchAction: 'none' }}
            disabled={isDone || briefing || phase !== 'play'}
            onPointerDown={(e) => onPointerDown(e, ing, i)}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            aria-label={t.blend.ingredients[ing.id]}
          >
            <span className="tile">
              <SafeImage asset={ASSET_OF[ing.id]} alt={t.blend.ingredients[ing.id]} />
              {isDone && (
                <svg className="check-icon" viewBox="0 0 34 34" aria-hidden="true">
                  <circle cx="17" cy="17" r="16" fill="#00AF66" />
                  <path d="M10 17.5 15 22.5 24.5 12.5" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </span>
            <span className="name">{t.blend.ingredients[ing.id]}</span>
          </button>
        );
      })}

      {/* 드래그 중 / 이동 중인 원물 */}
      {flyer && (
        <div className={`flyer ${flyer.mode === 'drag' ? 'drag' : ''}`} style={{ left: flyer.x, top: flyer.y, transform: `translate(-50%, -50%) scale(${flyer.scale})`, opacity: flyer.opacity }}>
          <SafeImage asset={ASSET_OF[flyer.id]} alt="" />
        </div>
      )}

      {!briefing && hintVisible && phase === 'play' && firstAvailable >= 0 && (
        <div className="tap-hint" style={{ left: centers[firstAvailable].x - 6, top: INGREDIENT_ROW.y + 24, zIndex: 30 }}>
          <FingerGuide mode="drag" />
        </div>
      )}

      {phase === 'play' && !briefing && !zoomPack && (
        <div className="step-copy" style={{ top: 64 }}>
          <div className="kicker">{t.blend.kicker}</div>
          <h1>{t.blend.title}</h1>
          <p style={{ whiteSpace: 'pre-line' }}>{t.blend.guide}</p>
        </div>
      )}

      {!zoomPack && (
        <div className="blend-counter" style={{ top: INGREDIENT_ROW.y + INGREDIENT_ROW.tileSize + 36 }} aria-live="polite">
          {t.blend.counter}{' '}
          <b>
            {count}/{INGREDIENTS.length}
          </b>
        </div>
      )}

      {briefing && (
        <StepBriefing
          hook={t.blend.hook}
          stepNo="03"
          title={t.blend.title}
          guide={t.blend.guide}
          demo={{ kind: 'drag', from: { x: centers[0].x, y: INGREDIENT_ROW.y + INGREDIENT_ROW.tileSize / 2 }, to: GRINDER_INTAKE }}
          onDone={() => setBriefing(false)}
        />
      )}
    </div>
  );
}

function BladeSvg({ active }: { active: boolean }) {
  return (
    <svg viewBox="0 0 100 100" aria-hidden="true">
      <ellipse cx="50" cy="50" rx="48" ry="48" fill="rgba(60,70,80,0.35)" />
      <g className="blade-rotor">
        {[0, 90, 180, 270].map((a) => (
          <path key={a} d="M50 50 L92 40 Q98 50 92 60 Z" fill={active ? '#E8EEF2' : '#C9D3DA'} stroke="#8A97A2" strokeWidth="1.5" transform={`rotate(${a} 50 50)`} />
        ))}
        <circle cx="50" cy="50" r="9" fill="#B9C3CB" stroke="#7E8A94" strokeWidth="2" />
      </g>
      {active && <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,0.6)" strokeWidth="3" strokeDasharray="18 30" />}
    </svg>
  );
}

function shade(hex: string, amt: number) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, (n >> 16) + amt));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 0xff) + amt));
  const b = Math.max(0, Math.min(255, (n & 0xff) + amt));
  return `rgb(${r},${g},${b})`;
}
