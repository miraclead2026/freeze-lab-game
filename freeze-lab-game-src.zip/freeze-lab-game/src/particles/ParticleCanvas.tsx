import { createContext, useContext, useEffect, useRef, type ReactNode } from 'react';
import { ParticleSystem } from './system';
import { STAGE } from '../config/gameConfig';

const ParticleContext = createContext<ParticleSystem | null>(null);

/** 스테이지 전체를 덮는 단일 Canvas. DPR을 반영해 선명하게 렌더링합니다. */
export function ParticleProvider({ children, reduced }: { children: ReactNode; reduced: boolean }) {
  const systemRef = useRef<ParticleSystem>(new ParticleSystem());
  const canvasRef = useRef<HTMLCanvasElement>(null);
  systemRef.current.reduced = reduced;

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = STAGE.width * dpr;
    canvas.height = STAGE.height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    let raf = 0;
    let last = performance.now();
    let idleFrames = 0;
    const sys = systemRef.current;

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (sys.particles.length > 0) {
        idleFrames = 0;
        sys.update(dt);
        ctx.clearRect(0, 0, STAGE.width, STAGE.height);
        sys.draw(ctx);
      } else if (idleFrames < 2) {
        idleFrames += 1;
        ctx.clearRect(0, 0, STAGE.width, STAGE.height);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <ParticleContext.Provider value={systemRef.current}>
      {children}
      <canvas ref={canvasRef} className="particle-canvas" aria-hidden="true" />
    </ParticleContext.Provider>
  );
}

export function useParticles(): ParticleSystem {
  const sys = useContext(ParticleContext);
  if (!sys) throw new Error('ParticleProvider가 필요합니다.');
  return sys;
}
