/**
 * Canvas 파티클 시스템 — 냉기, 얼음 결정, 수증기, 분말, 컨페티를 담당합니다.
 * 좌표는 스테이지 논리 좌표(390×844)이며, 화면 밖으로 나가면 즉시 제거됩니다.
 */
import { PARTICLES, STAGE } from '../config/gameConfig';

export type ParticleKind = 'ice' | 'mist' | 'vapor' | 'powder' | 'confetti' | 'check' | 'glow' | 'dust';

interface Particle {
  kind: ParticleKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number; // 남은 수명(초)
  maxLife: number;
  size: number;
  rot: number;
  vr: number;
  color: string;
  alpha: number;
  gravity: number;
  drag: number;
  sway: number;
  swayPhase: number;
  targetX?: number;
  targetY?: number;
  shape?: number; // 컨페티 형태 등
}

export interface EmitOptions {
  x: number;
  y: number;
  count?: number;
  color?: string;
  colors?: string[];
  spread?: number; // 발사 각도 범위(rad)
  angle?: number; // 발사 중심 각도
  speed?: number;
  size?: number;
  life?: number;
  targetX?: number;
  targetY?: number;
  power?: number; // 성공 효과 등 배율
}

const TAU = Math.PI * 2;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const pick = <T>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

export class ParticleSystem {
  particles: Particle[] = [];
  reduced = false;
  private lowPriority: ParticleKind[] = ['mist', 'dust', 'glow'];

  get max() {
    return this.reduced ? PARTICLES.reducedMotionMax : PARTICLES.maxCount;
  }

  clear() {
    this.particles.length = 0;
  }

  private push(p: Particle) {
    if (this.particles.length >= this.max) {
      // 낮은 우선순위 파티클부터 제거
      const idx = this.particles.findIndex((q) => this.lowPriority.includes(q.kind));
      this.particles.splice(idx >= 0 ? idx : 0, 1);
    }
    this.particles.push(p);
  }

  emit(kind: ParticleKind, o: EmitOptions) {
    const scale = this.reduced ? 0.4 : 1;
    const count = Math.max(1, Math.round((o.count ?? this.defaultCount(kind)) * scale));
    for (let i = 0; i < count; i++) this.push(this.make(kind, o));
  }

  private defaultCount(kind: ParticleKind) {
    switch (kind) {
      case 'ice':
        return 14;
      case 'mist':
        return 3;
      case 'vapor':
        return 12;
      case 'powder':
        return 6;
      case 'confetti':
        return 60;
      case 'check':
        return 8;
      case 'glow':
        return 6;
      case 'dust':
        return 4;
    }
  }

  private make(kind: ParticleKind, o: EmitOptions): Particle {
    const base: Particle = {
      kind,
      x: o.x,
      y: o.y,
      vx: 0,
      vy: 0,
      life: 1,
      maxLife: 1,
      size: 4,
      rot: rand(0, TAU),
      vr: rand(-3, 3),
      color: o.color ?? '#ffffff',
      alpha: 1,
      gravity: 0,
      drag: 0.985,
      sway: 0,
      swayPhase: rand(0, TAU),
      targetX: o.targetX,
      targetY: o.targetY,
    };
    const power = o.power ?? 1;
    switch (kind) {
      case 'ice': {
        const a = (o.angle ?? -Math.PI / 2) + rand(-(o.spread ?? TAU) / 2, (o.spread ?? TAU) / 2);
        const s = (o.speed ?? rand(120, 260)) * power;
        return {
          ...base,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s,
          life: rand(0.5, 0.9) * (0.7 + power * 0.3),
          maxLife: 1,
          size: (o.size ?? rand(3, 7)) * (0.8 + power * 0.25),
          color: pick(o.colors ?? ['#ffffff', '#dff3ff', '#bfe6ff', '#9fd6f5']),
          gravity: 90,
          drag: 0.97,
        };
      }
      case 'mist': {
        return {
          ...base,
          x: o.x + rand(-40, 40),
          y: o.y + rand(-10, 10),
          vx: rand(-14, 14),
          vy: rand(-26, -10),
          life: rand(1.6, 2.6),
          maxLife: 1,
          size: (o.size ?? rand(22, 44)) * power,
          color: '#ffffff',
          alpha: rand(0.16, 0.3) * Math.min(1, power),
          gravity: -8,
          drag: 0.995,
          sway: rand(6, 14),
        };
      }
      case 'vapor': {
        const a = -Math.PI / 2 + rand(-0.9, 0.9);
        const s = rand(18, 60);
        return {
          ...base,
          x: o.x + rand(-6, 6),
          y: o.y + rand(-6, 6),
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s - 30,
          life: rand(0.9, 1.5),
          maxLife: 1,
          size: rand(3, 9),
          color: pick(['#ffffff', '#eaf7ff', '#cfeeff']),
          alpha: 0.9,
          gravity: -45,
          drag: 0.99,
          sway: rand(4, 10),
        };
      }
      case 'powder': {
        return {
          ...base,
          x: o.x + rand(-5, 5),
          y: o.y + rand(-2, 2),
          vx: rand(-22, 22),
          vy: rand(10, 50),
          life: 3,
          maxLife: 3,
          size: rand(1.4, 3.6),
          color: o.colors ? pick(o.colors) : o.color ?? '#9CCB6A',
          alpha: rand(0.75, 1),
          gravity: 520,
          drag: 0.995,
          sway: rand(8, 22),
          shape: Math.random() < 0.6 ? 0 : 1, // 0 원형, 1 불규칙 입자
        };
      }
      case 'confetti': {
        const a = -Math.PI / 2 + rand(-1.2, 1.2);
        const s = rand(180, 420);
        return {
          ...base,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s,
          life: rand(1.6, 2.8),
          maxLife: 1,
          size: rand(5, 10),
          color: pick(o.colors ?? ['#00AF66', '#B9E36C', '#FFD166', '#FFFFFF', '#8FD0FF']),
          gravity: 380,
          drag: 0.97,
          sway: rand(20, 50),
          vr: rand(-8, 8),
          shape: Math.random() < 0.5 ? 0 : 1,
        };
      }
      case 'check': {
        const a = rand(0, TAU);
        const s = rand(40, 120);
        return {
          ...base,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s - 40,
          life: rand(1.4, 2.2),
          maxLife: 1,
          size: rand(9, 16),
          color: '#00AF66',
          gravity: 40,
          drag: 0.98,
          vr: rand(-1, 1),
        };
      }
      case 'glow': {
        return {
          ...base,
          x: o.x + rand(-70, 70),
          y: o.y + rand(-110, 110),
          vx: rand(-8, 8),
          vy: rand(-22, -8),
          life: rand(1.2, 2.4),
          maxLife: 1,
          size: rand(2, 5),
          color: pick(['#FFFFFF', '#FFF4C2', '#D9F5B0']),
          alpha: 1,
          drag: 0.99,
          sway: rand(4, 10),
        };
      }
      case 'dust': {
        return {
          ...base,
          x: o.x + rand(-60, 60),
          y: o.y + rand(-60, 60),
          vx: rand(-20, 20),
          vy: rand(-30, 10),
          life: rand(0.8, 1.6),
          maxLife: 1,
          size: rand(1.5, 3.5),
          color: o.color ?? '#9CCB6A',
          alpha: 0.8,
          gravity: 60,
          drag: 0.98,
        };
      }
    }
  }

  update(dt: number) {
    const ps = this.particles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt;
      p.vy += p.gravity * dt;
      p.vx *= p.drag;
      p.vy *= p.drag;
      if (p.sway) {
        p.swayPhase += dt * 4;
        p.x += Math.sin(p.swayPhase) * p.sway * dt;
      }
      if (p.kind === 'powder' && p.targetX !== undefined) {
        // 낱포 입구 방향으로 서서히 수렴
        p.vx += (p.targetX - p.x) * 3.5 * dt;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if (p.kind === 'mist') p.size += 14 * dt;

      const dead =
        p.life <= 0 ||
        p.x < -60 ||
        p.x > STAGE.width + 60 ||
        p.y < -80 ||
        p.y > STAGE.height + 60 ||
        (p.kind === 'powder' && p.targetY !== undefined && p.y >= p.targetY);
      if (dead) {
        ps[i] = ps[ps.length - 1];
        ps.pop();
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      const t = Math.max(0, p.life / (p.kind === 'powder' ? p.maxLife : p.maxLife * (p.kind === 'mist' ? 2.2 : 1)));
      const fade = p.kind === 'powder' ? 1 : Math.min(1, t * 1.6);
      ctx.globalAlpha = Math.max(0, p.alpha * fade);
      ctx.fillStyle = p.color;
      switch (p.kind) {
        case 'mist': {
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
          g.addColorStop(0, 'rgba(255,255,255,0.9)');
          g.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, TAU);
          ctx.fill();
          break;
        }
        case 'ice': {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.beginPath();
          // 마름모형 얼음 결정
          ctx.moveTo(0, -p.size);
          ctx.lineTo(p.size * 0.45, 0);
          ctx.lineTo(0, p.size);
          ctx.lineTo(-p.size * 0.45, 0);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha *= 0.6;
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-p.size, 0);
          ctx.lineTo(p.size, 0);
          ctx.stroke();
          ctx.restore();
          break;
        }
        case 'vapor':
        case 'glow': {
          ctx.shadowBlur = p.kind === 'glow' ? 8 : 4;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (p.kind === 'vapor' ? 1 + (1 - t) * 1.2 : 1), 0, TAU);
          ctx.fill();
          ctx.shadowBlur = 0;
          break;
        }
        case 'powder':
        case 'dust': {
          if (p.shape === 1) {
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot);
            ctx.fillRect(-p.size, -p.size * 0.6, p.size * 2, p.size * 1.2);
            ctx.restore();
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, TAU);
            ctx.fill();
          }
          break;
        }
        case 'confetti': {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          if (p.shape === 1) {
            ctx.beginPath();
            ctx.arc(0, 0, p.size * 0.45, 0, TAU);
            ctx.fill();
          } else {
            ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
          }
          ctx.restore();
          break;
        }
        case 'check': {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot * 0.3);
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(2, p.size * 0.22);
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
          ctx.beginPath();
          ctx.moveTo(-p.size * 0.45, 0);
          ctx.lineTo(-p.size * 0.1, p.size * 0.35);
          ctx.lineTo(p.size * 0.5, -p.size * 0.35);
          ctx.stroke();
          ctx.restore();
          break;
        }
      }
    }
    ctx.globalAlpha = 1;
  }
}
