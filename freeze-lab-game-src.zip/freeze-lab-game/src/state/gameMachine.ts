/**
 * 게임 상태 머신 — 한 페이지 안에서 순서대로 진행됩니다. (새로고침·URL 이동 없음)
 */
export const GAME_STATES = [
  'LOADING',
  'INTRO',
  'PROLOGUE',
  'STEP_1_FREEZE',
  'STEP_1_COMPLETE',
  'TRANSITION_TO_MICROSCOPE',
  'STEP_2_SUBLIMATION',
  'STEP_2_COMPLETE',
  'TRANSITION_TO_GRINDER',
  'STEP_3_GRINDING',
  'MISSION_STORY',
  'MISSION_COMPLETE',
] as const;

export type GameState = (typeof GAME_STATES)[number];

export interface GameContext {
  state: GameState;
  /** 현재 단계 미션 진행률 0~1 */
  progress: number;
  /** 각 단계 완료 여부 */
  done: [boolean, boolean, boolean];
  /** 몇 번째 플레이인지 (다시하기 시 리셋 애니메이션용 key) */
  run: number;
}

export type GameAction =
  | { type: 'NEXT' }
  | { type: 'GOTO'; state: GameState }
  | { type: 'PROGRESS'; value: number }
  | { type: 'RESTART' };

export const initialContext: GameContext = {
  state: 'LOADING',
  progress: 0,
  done: [false, false, false],
  run: 0,
};

/** 현재 상태가 속한 단계 인덱스(0~2). 로딩/인트로는 -1, 완료는 3 */
export function stepIndexOf(state: GameState): number {
  switch (state) {
    case 'STEP_1_FREEZE':
    case 'STEP_1_COMPLETE':
    case 'TRANSITION_TO_MICROSCOPE':
      return 0;
    case 'STEP_2_SUBLIMATION':
    case 'STEP_2_COMPLETE':
    case 'TRANSITION_TO_GRINDER':
      return 1;
    case 'STEP_3_GRINDING':
      return 2;
    case 'MISSION_STORY':
    case 'MISSION_COMPLETE':
      return 3;
    default:
      return -1;
  }
}

export function gameReducer(ctx: GameContext, action: GameAction): GameContext {
  switch (action.type) {
    case 'NEXT': {
      const i = GAME_STATES.indexOf(ctx.state);
      const next = GAME_STATES[Math.min(i + 1, GAME_STATES.length - 1)];
      return applyState(ctx, next);
    }
    case 'GOTO':
      return applyState(ctx, action.state);
    case 'PROGRESS':
      return { ...ctx, progress: Math.max(0, Math.min(1, action.value)) };
    case 'RESTART':
      return { ...initialContext, state: 'INTRO', run: ctx.run + 1 };
    default:
      return ctx;
  }
}

function applyState(ctx: GameContext, next: GameState): GameContext {
  const done: [boolean, boolean, boolean] = [...ctx.done] as [boolean, boolean, boolean];
  if (next === 'STEP_1_COMPLETE') done[0] = true;
  if (next === 'STEP_2_COMPLETE') done[1] = true;
  if (next === 'MISSION_STORY' || next === 'MISSION_COMPLETE') done[2] = true;
  // 새 단계가 시작되면 진행률 초기화
  const resets: GameState[] = ['STEP_1_FREEZE', 'STEP_2_SUBLIMATION', 'STEP_3_GRINDING'];
  const progress = resets.includes(next) ? 0 : ctx.progress;
  return { ...ctx, state: next, done, progress };
}
