import { useCallback, useEffect, useReducer } from 'react';
import { Stage } from './components/Stage';
import { ParticleProvider, useParticles } from './particles/ParticleCanvas';
import { MuteButton } from './components/ui/MuteButton';
import { RestartButton } from './components/ui/RestartButton';
import { LoadingScreen } from './components/steps/LoadingScreen';
import { IntroScreen } from './components/steps/IntroScreen';
import { PrologueScreen } from './components/steps/PrologueScreen';
import { FreezeStep } from './components/steps/FreezeStep';
import { MicroscopeStep } from './components/steps/MicroscopeStep';
import { GrinderStep } from './components/steps/GrinderStep';
import { CompleteScreen } from './components/steps/CompleteScreen';
import { StoryScreen } from './components/steps/StoryScreen';
import { gameReducer, initialContext } from './state/gameMachine';
import { usePreload } from './hooks/usePreload';
import { useReducedMotion } from './hooks/useReducedMotion';
import { TIMING } from './config/gameConfig';
import { IS_KIOSK, KIOSK_IDLE, MODE } from './config/mode';
import { sfx } from './audio/sfx';
import { useLang } from './i18n';

export default function App() {
  const reduced = useReducedMotion();
  return (
    <Stage>
      <ParticleProvider reduced={reduced}>
        <Game reduced={reduced} />
      </ParticleProvider>
    </Stage>
  );
}

function Game({ reduced }: { reduced: boolean }) {
  const { setLang } = useLang();
  const [ctx, dispatch] = useReducer(gameReducer, initialContext);
  const preload = usePreload();
  const particles = useParticles();
  const { state, run } = ctx;

  // LOADING → INTRO
  useEffect(() => {
    if (state === 'LOADING' && preload.ready) dispatch({ type: 'NEXT' });
  }, [state, preload.ready]);

  // 전환 상태는 시간이 지나면 자동으로 다음 상태로
  useEffect(() => {
    if (state === 'TRANSITION_TO_MICROSCOPE') {
      const t = setTimeout(() => dispatch({ type: 'NEXT' }), (reduced ? TIMING.zoomIn * 0.6 : TIMING.zoomIn) + 120);
      return () => clearTimeout(t);
    }
    if (state === 'TRANSITION_TO_GRINDER') {
      const t = setTimeout(() => dispatch({ type: 'NEXT' }), (reduced ? TIMING.zoomOut * 0.6 : TIMING.zoomOut) + 80);
      return () => clearTimeout(t);
    }
  }, [state, reduced]);

  const next = useCallback(() => dispatch({ type: 'NEXT' }), []);
  const setProgress = useCallback((value: number) => dispatch({ type: 'PROGRESS', value }), []);
  const restart = useCallback(() => {
    particles.clear();
    if (IS_KIOSK) setLang('ko'); // 다음 고객을 위해 기본 언어로
    dispatch({ type: 'RESTART' });
  }, [particles, setLang]);

  // 배경음악: 인트로에서 "연구 시작하기"를 누른 뒤(오디오 unlock 이후) 무한 루프로 재생
  useEffect(() => {
    if (state === 'PROLOGUE') sfx.bgm();
  }, [state]);

  // 키오스크: 무조작 시 자동으로 처음 화면으로 (다음 고객을 위해)
  useEffect(() => {
    if (!IS_KIOSK || state === 'LOADING' || state === 'INTRO') return;
    const limit = state === 'MISSION_COMPLETE' ? KIOSK_IDLE.completeMs : KIOSK_IDLE.playingMs;
    let t = 0;
    const arm = () => {
      window.clearTimeout(t);
      t = window.setTimeout(restart, limit);
    };
    const evs: (keyof WindowEventMap)[] = ['pointerdown', 'pointermove', 'keydown', 'touchstart'];
    evs.forEach((e) => window.addEventListener(e, arm, { passive: true }));
    arm();
    return () => {
      window.clearTimeout(t);
      evs.forEach((e) => window.removeEventListener(e, arm));
    };
  }, [state, restart]);

  // 키오스크: 첫 터치에서 브라우저 전체화면 요청 (webOS 웹브라우저·크롬의 주소창/툴바 숨김).
  // 전체화면이 풀리면(예: 홈 버튼) 다음 터치에서 다시 요청합니다.
  useEffect(() => {
    if (!IS_KIOSK) return;
    const el = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> | void };
    const goFull = () => {
      if (document.fullscreenElement) return;
      try {
        const p = el.requestFullscreen ? el.requestFullscreen({ navigationUI: 'hide' }) : el.webkitRequestFullscreen?.();
        (p as Promise<void> | undefined)?.catch?.(() => {});
      } catch {
        /* 지원하지 않는 브라우저 — 무시 */
      }
    };
    document.addEventListener('pointerup', goFull, { passive: true });
    document.addEventListener('click', goFull, { passive: true });
    return () => {
      document.removeEventListener('pointerup', goFull);
      document.removeEventListener('click', goFull);
    };
  }, []);

  // 키오스크: 길게 누르기 메뉴·텍스트 선택·핀치 줌 등 브라우저 기본 동작 차단
  useEffect(() => {
    document.documentElement.dataset.mode = MODE;
    if (!IS_KIOSK) return;
    const block = (e: Event) => e.preventDefault();
    document.addEventListener('contextmenu', block);
    document.addEventListener('gesturestart', block);
    document.addEventListener('dblclick', block);
    return () => {
      document.removeEventListener('contextmenu', block);
      document.removeEventListener('gesturestart', block);
      document.removeEventListener('dblclick', block);
    };
  }, []);


  return (
    <div key={run} className="scene">
      {state === 'LOADING' && <LoadingScreen progress={preload.progress} />}
      {state === 'INTRO' && <IntroScreen onStart={next} />}
      {state === 'PROLOGUE' && <PrologueScreen reduced={reduced} onStart={next} />}

      {(state === 'STEP_1_FREEZE' || state === 'STEP_1_COMPLETE' || state === 'TRANSITION_TO_MICROSCOPE') && (
        <FreezeStep
          phase={state === 'STEP_1_FREEZE' ? 'play' : state === 'STEP_1_COMPLETE' ? 'complete' : 'zoom'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
          onPopupDone={next}
        />
      )}

      {/* 줌아웃 전환 중에는 STEP 3 장면이 아래에서 먼저 나타납니다 */}
      {(state === 'TRANSITION_TO_GRINDER' || state === 'STEP_3_GRINDING') && (
        <GrinderStep
          phase={state === 'TRANSITION_TO_GRINDER' ? 'enter' : 'play'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
        />
      )}

      {(state === 'STEP_2_SUBLIMATION' || state === 'STEP_2_COMPLETE' || state === 'TRANSITION_TO_GRINDER') && (
        <MicroscopeStep
          phase={state === 'STEP_2_SUBLIMATION' ? 'play' : state === 'STEP_2_COMPLETE' ? 'complete' : 'zoom'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
          onPopupDone={next}
        />
      )}

      {state === 'MISSION_STORY' && <StoryScreen reduced={reduced} onDone={next} />}
      {state === 'MISSION_COMPLETE' && <CompleteScreen reduced={reduced} onRestart={restart} />}

      {state !== 'LOADING' && <MuteButton />}
      {state !== 'LOADING' && state !== 'INTRO' && <RestartButton onRestart={restart} />}
    </div>
  );
}
