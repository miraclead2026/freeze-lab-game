import { useCallback, useEffect, useReducer } from 'react';
import { Stage } from './components/Stage';
import { ParticleProvider, useParticles } from './particles/ParticleCanvas';
import { ProgressHeader } from './components/ui/ProgressHeader';
import { MuteButton } from './components/ui/MuteButton';
import { LoadingScreen } from './components/steps/LoadingScreen';
import { IntroScreen } from './components/steps/IntroScreen';
import { FreezeStep } from './components/steps/FreezeStep';
import { MicroscopeStep } from './components/steps/MicroscopeStep';
import { GrinderStep } from './components/steps/GrinderStep';
import { CompleteScreen } from './components/steps/CompleteScreen';
import { StoryScreen } from './components/steps/StoryScreen';
import { gameReducer, initialContext, stepIndexOf } from './state/gameMachine';
import { usePreload } from './hooks/usePreload';
import { useReducedMotion } from './hooks/useReducedMotion';
import { TIMING } from './config/gameConfig';

export default function App() {
  const reduced = useReducedMotion();
  return (
    <Stage>
      <ParticleProvider reduced={reduced}>
        <Game reduced={reduced} />
      </ParticleProvider>
    </Stage>
  );
}

function Game({ reduced }: { reduced: boolean }) {
  const [ctx, dispatch] = useReducer(gameReducer, initialContext);
  const preload = usePreload();
  const particles = useParticles();
  const { state, progress, done, run } = ctx;

  // LOADING → INTRO
  useEffect(() => {
    if (state === 'LOADING' && preload.ready) dispatch({ type: 'NEXT' });
  }, [state, preload.ready]);

  // 전환 상태는 시간이 지나면 자동으로 다음 상태로
  useEffect(() => {
    if (state === 'TRANSITION_TO_MICROSCOPE') {
      const t = setTimeout(() => dispatch({ type: 'NEXT' }), (reduced ? TIMING.zoomIn * 0.6 : TIMING.zoomIn) + 120);
      return () => clearTimeout(t);
    }
    if (state === 'TRANSITION_TO_GRINDER') {
      const t = setTimeout(() => dispatch({ type: 'NEXT' }), (reduced ? TIMING.zoomOut * 0.6 : TIMING.zoomOut) + 80);
      return () => clearTimeout(t);
    }
  }, [state, reduced]);

  const next = useCallback(() => dispatch({ type: 'NEXT' }), []);
  const setProgress = useCallback((value: number) => dispatch({ type: 'PROGRESS', value }), []);
  const restart = useCallback(() => {
    particles.clear();
    dispatch({ type: 'RESTART' });
  }, [particles]);

  const stepIndex = stepIndexOf(state);
  const showHud = stepIndex >= 0;
  const progressLabel = stepIndex === 0 ? '동결 진행률' : stepIndex === 1 ? '승화 진행률' : stepIndex === 2 ? '블렌딩 진행률' : '미션 완료';

  return (
    <div key={run} className="scene">
      {state === 'LOADING' && <LoadingScreen progress={preload.progress} />}
      {state === 'INTRO' && <IntroScreen onStart={next} />}

      {(state === 'STEP_1_FREEZE' || state === 'STEP_1_COMPLETE' || state === 'TRANSITION_TO_MICROSCOPE') && (
        <FreezeStep
          phase={state === 'STEP_1_FREEZE' ? 'play' : state === 'STEP_1_COMPLETE' ? 'complete' : 'zoom'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
          onPopupDone={next}
        />
      )}

      {/* 줌아웃 전환 중에는 STEP 3 장면이 아래에서 먼저 나타납니다 */}
      {(state === 'TRANSITION_TO_GRINDER' || state === 'STEP_3_GRINDING') && (
        <GrinderStep
          phase={state === 'TRANSITION_TO_GRINDER' ? 'enter' : 'play'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
        />
      )}

      {(state === 'STEP_2_SUBLIMATION' || state === 'STEP_2_COMPLETE' || state === 'TRANSITION_TO_GRINDER') && (
        <MicroscopeStep
          phase={state === 'STEP_2_SUBLIMATION' ? 'play' : state === 'STEP_2_COMPLETE' ? 'complete' : 'zoom'}
          reduced={reduced}
          onProgress={setProgress}
          onComplete={next}
          onPopupDone={next}
        />
      )}

      {state === 'MISSION_STORY' && <StoryScreen reduced={reduced} onDone={next} />}
      {state === 'MISSION_COMPLETE' && <CompleteScreen reduced={reduced} onRestart={restart} />}

      {showHud && state !== 'MISSION_COMPLETE' && state !== 'MISSION_STORY' && (
        <ProgressHeader activeIndex={stepIndex} done={done} progress={progress} progressLabel={progressLabel} />
      )}
      {state !== 'LOADING' && <MuteButton />}
    </div>
  );
}
