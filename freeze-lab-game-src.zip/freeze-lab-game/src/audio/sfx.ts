/**
 * 효과음 — Web Audio API로 합성 (외부 오디오 파일 없음).
 * 첫 사용자 제스처에서 unlock() 호출. muted 상태는 localStorage에 기억합니다.
 */

type Ctx = AudioContext;

class Sfx {
  private ctx: Ctx | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private grindNodes: { osc: OscillatorNode; osc2: OscillatorNode; noise: AudioBufferSourceNode; gain: GainNode; filter: BiquadFilterNode } | null = null;
  muted = false;
  listeners = new Set<(m: boolean) => void>();

  constructor() {
    try {
      this.muted = localStorage.getItem('fl-muted') === '1';
    } catch {
      /* ignore */
    }
  }

  /** 사용자 제스처 안에서 호출 — 오디오 컨텍스트 생성/재개 */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(this.ctx.destination);
      // 화이트 노이즈 버퍼 (2초)
      const len = this.ctx.sampleRate * 2;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem('fl-muted', m ? '1' : '0');
    } catch {
      /* ignore */
    }
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.03);
    this.listeners.forEach((l) => l(m));
  }
  toggle() {
    this.unlock();
    this.setMuted(!this.muted);
  }

  private get ready() {
    return !!this.ctx && !!this.master && !this.muted;
  }

  private tone(freq: number, dur: number, opts: { type?: OscillatorType; gain?: number; to?: number; delay?: number; attack?: number } = {}) {
    if (!this.ready) return;
    const ctx = this.ctx!;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = opts.type ?? 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    if (opts.to) osc.frequency.exponentialRampToValueAtTime(opts.to, t0 + dur);
    const a = opts.attack ?? 0.005;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(opts.gain ?? 0.2, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(this.master!);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  private noise(dur: number, opts: { gain?: number; freq?: number; q?: number; type?: BiquadFilterType; delay?: number; sweepTo?: number; attack?: number } = {}) {
    if (!this.ready || !this.noiseBuf) return;
    const ctx = this.ctx!;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = opts.type ?? 'bandpass';
    f.frequency.setValueAtTime(opts.freq ?? 2000, t0);
    if (opts.sweepTo) f.frequency.exponentialRampToValueAtTime(opts.sweepTo, t0 + dur);
    f.Q.value = opts.q ?? 1;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(opts.gain ?? 0.15, t0 + (opts.attack ?? 0.01));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f).connect(g).connect(this.master!);
    src.start(t0);
    src.stop(t0 + dur + 0.05);
  }

  // ===== 개별 효과음 =====
  /** 버튼 */
  click() {
    this.tone(720, 0.07, { gain: 0.12, to: 520 });
    this.noise(0.04, { gain: 0.05, freq: 4000 });
  }
  /** STEP 1 터치: 얼음이 얼어붙는 짧은 파삭 소리 */
  freezeTap(progress: number) {
    this.noise(0.09, { gain: 0.18, freq: 3200 + progress * 2600, q: 2.5, type: 'highpass' });
    this.tone(1400 + progress * 900, 0.08, { gain: 0.06, to: 900 });
    this.tone(260 - progress * 80, 0.05, { gain: 0.08, type: 'triangle' });
  }
  /** 마지막 터치 — 결정이 크게 퍼짐 */
  iceBurst() {
    this.noise(0.5, { gain: 0.25, freq: 5000, q: 0.8, type: 'highpass' });
    [1568, 2093, 2637, 3136].forEach((f, i) => this.tone(f, 0.6, { gain: 0.08, delay: i * 0.05 }));
    this.tone(180, 0.35, { gain: 0.15, type: 'triangle', to: 60 });
  }
  /** 냉기 바람 */
  wind() {
    this.noise(1.2, { gain: 0.06, freq: 500, q: 0.6, sweepTo: 1200, attack: 0.3 });
  }
  /** 줌인/줌아웃 */
  zoomIn() {
    this.tone(220, 1.6, { gain: 0.12, to: 880, type: 'sine', attack: 0.2 });
    this.noise(1.6, { gain: 0.08, freq: 600, sweepTo: 3500, q: 0.7, attack: 0.3 });
  }
  zoomOut() {
    this.tone(880, 1.3, { gain: 0.12, to: 220, type: 'sine', attack: 0.1 });
    this.noise(1.3, { gain: 0.08, freq: 3500, sweepTo: 500, q: 0.7, attack: 0.1 });
  }
  /** 물방울 집기 */
  dropPick() {
    this.tone(420, 0.12, { gain: 0.16, to: 980, type: 'sine' });
  }
  /** 물방울 드래그 중 (작게) */
  dropMove() {
    this.tone(600, 0.03, { gain: 0.03 });
  }
  /** 제자리로 복귀 */
  snapBack() {
    this.tone(500, 0.1, { gain: 0.1, to: 260, type: 'triangle' });
  }
  /** 승화: 치이익 하며 사라짐 */
  vaporize() {
    this.noise(0.55, { gain: 0.2, freq: 2400, sweepTo: 7000, q: 1.2, attack: 0.02 });
    this.tone(880, 0.35, { gain: 0.07, to: 1760 });
  }
  /** 원물 집기 */
  grab() {
    this.tone(300, 0.08, { gain: 0.12, to: 480, type: 'triangle' });
  }
  /** 원물 투입 (툭) */
  dropIn() {
    this.tone(160, 0.12, { gain: 0.25, to: 70, type: 'triangle' });
    this.noise(0.08, { gain: 0.12, freq: 1200, q: 1 });
  }
  /** 분쇄기 작동 (연속) — level 0: 정지, 1: 대기, 2: 작동 */
  grinder(level: 0 | 1 | 2) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const ctx = this.ctx;
    if (!this.grindNodes) {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      const osc2 = ctx.createOscillator();
      osc2.type = 'square';
      const noise = ctx.createBufferSource();
      noise.buffer = this.noiseBuf;
      noise.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 500;
      const gain = ctx.createGain();
      gain.gain.value = 0;
      osc.connect(filter);
      osc2.connect(filter);
      noise.connect(filter);
      filter.connect(gain).connect(this.master);
      osc.start();
      osc2.start();
      noise.start();
      this.grindNodes = { osc, osc2, noise, gain, filter };
    }
    const n = this.grindNodes;
    const t = ctx.currentTime;
    const target = level === 0 ? 0 : level === 1 ? 0.035 : 0.11;
    const freq = level === 2 ? 95 : 48;
    n.gain.gain.setTargetAtTime(this.muted ? 0 : target, t, 0.12);
    n.osc.frequency.setTargetAtTime(freq, t, 0.15);
    n.osc2.frequency.setTargetAtTime(freq * 1.5, t, 0.15);
    n.filter.frequency.setTargetAtTime(level === 2 ? 1400 : 500, t, 0.15);
  }
  /** 분말 떨어짐 (사각사각) */
  sprinkle() {
    this.noise(0.9, { gain: 0.12, freq: 6000, q: 0.5, type: 'highpass', attack: 0.05 });
  }
  /** 단계 완료 차임 */
  success() {
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => this.tone(f, 0.5, { gain: 0.14, delay: i * 0.11, type: 'triangle' }));
  }
  /** 미션 완료 팡파르 + 컨페티 */
  complete() {
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => this.tone(f, 0.7, { gain: 0.14, delay: i * 0.09, type: 'triangle' }));
    [1046.5, 1318.5, 1568].forEach((f, i) => this.tone(f, 1.2, { gain: 0.1, delay: 0.5 + i * 0.05, type: 'sine' }));
    this.noise(0.6, { gain: 0.14, freq: 3000, sweepTo: 8000, q: 0.5, type: 'highpass', delay: 0.05 });
  }
  /** 제품 등장 (슝) */
  rise() {
    this.noise(0.5, { gain: 0.1, freq: 800, sweepTo: 3000, q: 0.9, attack: 0.05 });
    this.tone(330, 0.5, { gain: 0.08, to: 660 });
  }
  /** 브리핑 등장 */
  brief() {
    this.tone(660, 0.18, { gain: 0.1, type: 'triangle' });
    this.tone(880, 0.22, { gain: 0.1, type: 'triangle', delay: 0.1 });
  }
  /** 팝 (체크 아이콘 등) */
  pop() {
    this.tone(700, 0.09, { gain: 0.12, to: 1100 });
  }
}

export const sfx = new Sfx();
