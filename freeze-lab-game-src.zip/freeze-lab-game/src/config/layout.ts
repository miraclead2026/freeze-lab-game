/**
 * 장면 레이아웃 — 컨테이너(390×844) 기준 상대 좌표.
 * 브로콜리 줌인과 현미경은 같은 중심점(LENS_CENTER)을 공유해 장면이 끊기지 않습니다.
 */
import { ASSETS } from './assets';
import { SUBLIMATION } from './gameConfig';

export const LENS_CENTER = { x: 195, y: 420 } as const;

/** STEP 1 브로콜리 박스 (중심 = LENS_CENTER) */
export const BROCCOLI_BOX = { size: 300, cx: LENS_CENTER.x, cy: LENS_CENTER.y } as const;

/** STEP 2 현미경 렌즈 */
export const LENS = { d: SUBLIMATION.lensDiameter, cx: LENS_CENTER.x, cy: LENS_CENTER.y } as const;

/** STEP 3 분쇄기 박스 */
export const GRINDER_BOX = { x: 95, y: 196, w: 210, h: 210 } as const;

/** STEP 3 닥터샐러드 낱포 박스 — 배출구 바로 아래에 세워 놓습니다. */
export const PACK_BOX = { w: 49, h: 176 } as const; // 닥터샐러드(뜯어진 버전) 실제 비율 156:559

/** STEP 3 원물 카드 행 (y = 카드 상단) */
export const INGREDIENT_ROW = { y: 604, tileSize: 84, gap: 6 } as const;

/** 비율 앵커 → 절대 좌표 */
export function anchorOf(box: { x: number; y: number; w: number; h: number }, a: { x: number; y: number }) {
  return { x: box.x + box.w * a.x, y: box.y + box.h * a.y };
}

const grinderAnchors = ASSETS.grinderBase.anchors!;
export const GRINDER_INTAKE = anchorOf(GRINDER_BOX, grinderAnchors.intake);
export const GRINDER_BLADE = anchorOf(GRINDER_BOX, grinderAnchors.blade);
export const GRINDER_OUTLET = anchorOf(GRINDER_BOX, grinderAnchors.outlet);
export const GRINDER_LIGHT = anchorOf(GRINDER_BOX, grinderAnchors.light);

/** 낱포 박스 위치: 뜯어진 입구가 배출구 아래 64px 지점에 오도록 (분말이 떨어지는 거리) */
const packMouthAnchor = ASSETS.doctorSaladPackOpen.anchors!.mouth;
export const PACK_POS = {
  x: GRINDER_OUTLET.x - 8 - PACK_BOX.w * packMouthAnchor.x,
  y: GRINDER_OUTLET.y + 64 - PACK_BOX.h * packMouthAnchor.y,
  w: PACK_BOX.w,
  h: PACK_BOX.h,
} as const;
export const PACK_MOUTH = anchorOf(PACK_POS, packMouthAnchor);

/** 원물 카드 4개의 중심 좌표 */
export function ingredientCenters(count: number) {
  const { tileSize, gap, y } = INGREDIENT_ROW;
  const total = count * tileSize + (count - 1) * gap;
  const startX = (390 - total) / 2;
  return Array.from({ length: count }, (_, i) => ({
    x: startX + i * (tileSize + gap) + tileSize / 2,
    y: y + tileSize / 2,
  }));
}

/** 드롭 존: 원물을 이 반경 안에 놓으면 투입구로 들어갑니다 */
export const GRINDER_DROP_RADIUS = 78;
