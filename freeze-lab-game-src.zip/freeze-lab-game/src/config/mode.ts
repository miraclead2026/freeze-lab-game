/**
 * 실행 모드 — 한 빌드로 두 가지 환경을 지원합니다.
 *   kiosk  : 현장 32" 터치 모니터(세로). 마지막 화면에 QR (고객이 자기 폰으로 스캔) · 무조작 시 자동 처음으로
 *   mobile : 고객 본인 폰. 마지막 화면에 "혜택 받으러 가기" 버튼 (REWARD_URL로 이동)
 *
 * 판별 순서
 *   1. URL 파라미터  ?mode=kiosk / ?mode=mobile  (명시가 항상 우선)
 *   2. file:// 로 열었으면 kiosk (현장 PC에서 로컬 파일로 실행하는 경우)
 *   3. 그 외(호스팅 링크)는 mobile
 */
export type RunMode = 'kiosk' | 'mobile';

function detect(): RunMode {
  // 빌드 시 고정: VITE_FORCE_MODE=kiosk npm run build:single → 키오스크 전용 파일
  const forced = import.meta.env.VITE_FORCE_MODE as string | undefined;
  if (forced === 'kiosk' || forced === 'mobile') return forced;
  try {
    const q = new URLSearchParams(window.location.search).get('mode');
    if (q === 'kiosk' || q === 'mobile') return q;
    if (window.location.protocol === 'file:') return 'kiosk';
  } catch {
    /* ignore */
  }
  return 'mobile';
}

export const MODE: RunMode = detect();
export const IS_KIOSK = MODE === 'kiosk';

/** 키오스크: 이 시간(ms) 동안 아무 조작이 없으면 처음 화면으로 돌아갑니다. */
export const KIOSK_IDLE = {
  /** 미션 완료 화면에서 */
  completeMs: 75_000,
  /** 게임 도중(인트로 제외) */
  playingMs: 180_000,
} as const;
