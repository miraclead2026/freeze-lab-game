import { IS_KIOSK } from './mode';

/**
 * FREEZE LAB 게임 설정 파일
 * 온도·터치 횟수·물 분자 개수·원물 개수 등 게임 밸런스 상수를 한곳에서 관리합니다.
 */

/** 최종 화면 QR에 연결할 URL. 비어 있으면 "QR URL 입력 필요" 플레이스홀더가 표시됩니다. */
export const REWARD_URL = 'https://omopl.com/sh/9cecac74';

/**
 * 논리 해상도. 모든 좌표는 이 캔버스를 기준으로 합니다.
 * - mobile: 390×844 (폰 세로)
 * - kiosk : 474×844 (9:16 — LG 32U889SA-W 세로 2160×3840에 여백 없이 꽉 참)
 * 장면 요소는 390 폭 기준으로 설계되어 있고, 키오스크에서는 LAYOUT_X 만큼 가운데로 밀어 배치합니다.
 * 배경·카드처럼 left/right 로 늘어나는 요소는 자동으로 전체 폭을 씁니다.
 */
export const STAGE = { width: IS_KIOSK ? 474 : 390, height: 844 } as const;
/** 390 폭 기준 좌표를 현재 스테이지 가운데로 옮기는 가로 오프셋 (mobile 0 / kiosk 42) */
export const LAYOUT_X = (STAGE.width - 390) / 2;

/** STEP 1 급속 동결 */
export const FREEZE = {
  startTemp: 20, // ℃
  targetTemp: -40, // ℃
  tapsToComplete: 15, // 총 터치 횟수
  /** 터치 1회당 하강 온도 = (start - target) / taps = 4℃ */
  get tempPerTap() {
    return (this.startTemp - this.targetTemp) / this.tapsToComplete;
  },
  hapticMs: 12,
} as const;

/** STEP 2 수분 승화 */
export const SUBLIMATION = {
  moleculeCount: 5, // 8 → 5 (플레이 시간 단축)
  lensDiameter: 330, // 현미경 원형 마스크 지름(px)
  moleculeRadius: 22, // 물 분자 SVG 반지름(px). 터치 영역은 별도로 56px 이상 확보
  travelMs: 900, // 분자가 경계까지 이동하는 시간
  spawnIntervalMs: 160, // 분자 순차 등장 간격
} as const;

/** STEP 3 원물 블렌딩 */
export const BLEND = {
  ingredientCount: 4,
  flyMs: 750, // 원물이 투입구까지 날아가는 시간
  powderDelayMs: 700, // 투입 후 분말 배출까지 지연
  powderDurationMs: 1100, // 분말이 떨어지는 시간
  idleBladeRpm: 24, // 대기 회전 속도
  activeBladeRpm: 240, // 작동 회전 속도
} as const;

/** 공통 타이밍 (ms) */
export const TIMING = {
  briefing: 1500, // 단계 시작 안내 노출
  successPopup: 1400, // 성공 팝업 노출 (1.2~1.5초)
  resultHold: 1000, // 결과를 볼 수 있는 대기 시간
  zoomIn: 1900, // 브로콜리 → 현미경 줌인
  zoomOut: 1500, // 현미경 → 연구실 줌아웃
  finalZoom: 1200, // 닥터샐러드 확대
} as const;

/** 파티클 성능 제한 */
export const PARTICLES = {
  maxCount: 420,
  reducedMotionMax: 120,
} as const;

/** 브랜드 컬러 */
export const COLORS = {
  green: '#00AF66',
  lime: '#B9E36C',
  ivory: '#F8F5EC',
  ink: '#1E2A24',
  ice: '#BFE6FF',
  powder: {
    broccoli: '#9CCB6A',
    carrot: '#F28C28',
    beet: '#A8285C',
    kale: '#2F7A3E',
  },
} as const;

/** STEP 3 원물 정의 */
export type IngredientId = 'broccoli' | 'carrot' | 'beet' | 'kale';
export const INGREDIENTS: { id: IngredientId; label: string; powder: string }[] = [
  { id: 'broccoli', label: '브로콜리', powder: COLORS.powder.broccoli },
  { id: 'carrot', label: '당근', powder: COLORS.powder.carrot },
  { id: 'beet', label: '비트', powder: COLORS.powder.beet },
  { id: 'kale', label: '케일', powder: COLORS.powder.kale },
];
