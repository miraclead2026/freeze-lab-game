/**
 * 이미지 소스 매니페스트
 * - 모든 경로는 public/assets/freeze-lab/ 기준
 * - anchor 값은 이미지 폭·높이에 대한 비율(0~1)이며, 이미지 크기가 바뀌어도 좌표가 어긋나지 않습니다.
 * - 닥터샐러드 낱포(doctor-salad-pack.png)만 교체하면 실제 제품으로 바뀝니다.
 */

import assetMap from 'virtual:freeze-lab-assets';

/** 일반 빌드: public/assets/freeze-lab/<file> 경로 · 단일 파일 빌드: data URI (vite.config.ts 참고) */
const resolve = (file: string) => assetMap[file] ?? `${import.meta.env.BASE_URL}assets/freeze-lab/${file}`;

export interface AssetDef {
  key: AssetKey;
  file: string;
  /** 이미지 로딩 실패 시 표시할 플레이스홀더 색상 */
  fallbackColor: string;
  /** 사용 위치 */
  usedIn: string;
  /** 비율 기반 앵커 포인트 (선택) */
  anchors?: Record<string, { x: number; y: number }>;
}

export type AssetKey =
  | 'broccoliFresh'
  | 'frostTexture'
  | 'frostTile'
  | 'microscopeTissue'
  | 'fdBroccoli'
  | 'fdCarrot'
  | 'fdBeet'
  | 'fdKale'
  | 'grinderBase'
  | 'doctorSaladPack'
  | 'doctorSaladPackOpen'
  | 'packDaily'
  | 'packNutrition'
  | 'packFermented'
  | 'packProteinGold'
  | 'logoLifemeal'
  | 'logoFreezeLab';

export const ASSETS: Record<AssetKey, AssetDef> = {
  broccoliFresh: {
    key: 'broccoliFresh',
    file: 'broccoli-fresh.webp',
    fallbackColor: '#4C9A3F',
    usedIn: 'STEP 1 급속 동결 · 현미경 줌인 전환',
    anchors: { center: { x: 0.5, y: 0.5 } },
  },
  frostTexture: {
    key: 'frostTexture',
    file: 'frost-texture.webp',
    fallbackColor: 'rgba(191,230,255,0.5)',
    usedIn: 'STEP 1 브로콜리 성에 오버레이 · 화면 가장자리 서리',
  },
  frostTile: {
    key: 'frostTile',
    file: 'frost-tile.webp',
    fallbackColor: 'rgba(255,255,255,0.4)',
    usedIn: 'STEP 1 브로콜리 표면 성에(브로콜리 형태 마스크 · 타일 반복) · 윤곽 성에 띠',
  },
  microscopeTissue: {
    key: 'microscopeTissue',
    file: 'microscope-tissue.webp',
    fallbackColor: '#CFE9C5',
    usedIn: 'STEP 2 현미경 배경 · 줌인/줌아웃 전환',
  },
  fdBroccoli: {
    key: 'fdBroccoli',
    file: 'fd-broccoli.webp',
    fallbackColor: '#9CCB6A',
    usedIn: 'STEP 2→3 줌아웃 전환 · STEP 3 원물 카드',
  },
  fdCarrot: { key: 'fdCarrot', file: 'fd-carrot.webp', fallbackColor: '#F28C28', usedIn: 'STEP 3 원물 카드' },
  fdBeet: { key: 'fdBeet', file: 'fd-beet.webp', fallbackColor: '#A8285C', usedIn: 'STEP 3 원물 카드' },
  fdKale: { key: 'fdKale', file: 'fd-kale.webp', fallbackColor: '#2F7A3E', usedIn: 'STEP 3 원물 카드' },
  grinderBase: {
    key: 'grinderBase',
    file: 'grinder-base.webp',
    fallbackColor: '#E8E4D8',
    usedIn: 'STEP 3 분쇄기 본체',
    anchors: {
      /** 상단 투입구(호퍼 입구) 중심 — 원물 이동 도착점 */
      intake: { x: 0.5, y: 0.13 },
      /** 호퍼 안 회전 날 위치 */
      blade: { x: 0.5, y: 0.17 },
      /** 하단 배출구 끝 — 분말 생성 지점 */
      outlet: { x: 0.36, y: 0.72 },
      /** 작동 표시등 */
      light: { x: 0.64, y: 0.83 },
    },
  },
  doctorSaladPack: {
    key: 'doctorSaladPack',
    // 실제 제품 정면 누끼 (제공된 촬영본에서 배경만 제거 · 글자/로고 변형 없음)
    file: 'doctor-salad-pack.png',
    fallbackColor: '#F3F0E6',
    usedIn: 'STEP 3 밀봉 완료 크로스페이드 · MISSION COMPLETE 라인업',
  },
  doctorSaladPackOpen: {
    key: 'doctorSaladPackOpen',
    // 절취선 위를 뜯어낸 버전 (원본 이미지를 절취선에서 잘라 만든 파생본)
    file: 'doctor-salad-pack-open.png',
    fallbackColor: '#F3F0E6',
    usedIn: 'STEP 3 분쇄기 배출구 아래 낱포 (분말이 들어가는 입구)',
    anchors: {
      /** 뜯어진 입구(상단 중앙) — 분말이 사라지는 지점 */
      mouth: { x: 0.5, y: 0.03 },
    },
  },
  packDaily: { key: 'packDaily', file: 'pack-lifemeal-daily.png', fallbackColor: '#E6F4CF', usedIn: 'MISSION COMPLETE 라인업' },
  packNutrition: { key: 'packNutrition', file: 'pack-nutrition.png', fallbackColor: '#1E3D33', usedIn: 'MISSION COMPLETE 라인업' },
  packFermented: { key: 'packFermented', file: 'pack-fermented.png', fallbackColor: '#4A2E1E', usedIn: 'MISSION COMPLETE 라인업' },
  packProteinGold: { key: 'packProteinGold', file: 'pack-protein-gold.png', fallbackColor: '#D9DCE0', usedIn: 'MISSION COMPLETE 라인업' },
  logoLifemeal: { key: 'logoLifemeal', file: 'logo-lifemeal.png', fallbackColor: 'transparent', usedIn: '메인(인트로) 화면 메인 로고' },
  logoFreezeLab: { key: 'logoFreezeLab', file: 'logo-freezelab.png', fallbackColor: 'transparent', usedIn: '메인(인트로) 화면 서브 로고' },
};

/** MISSION COMPLETE 라인업 (낱포 5종) */
export const PACK_LINEUP: { key: AssetKey; label: string }[] = [
  { key: 'doctorSaladPack', label: '닥터샐러드' },
  { key: 'packDaily', label: '라이프밀 데일리' },
  { key: 'packNutrition', label: '영양식' },
  { key: 'packFermented', label: '발효건강식' },
  { key: 'packProteinGold', label: '프로틴골드' },
];

export const assetUrl = (key: AssetKey) => resolve(ASSETS[key].file);
export const ALL_ASSET_KEYS = Object.keys(ASSETS) as AssetKey[];
