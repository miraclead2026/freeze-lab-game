import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { STRINGS, type Lang, type Strings } from './strings';

interface LangCtx {
  lang: Lang;
  t: Strings;
  setLang: (l: Lang) => void;
}

const Ctx = createContext<LangCtx>({ lang: 'ko', t: STRINGS.ko, setLang: () => {} });

/** 기본 한국어. 인트로 화면의 언어 선택으로 변경. */
export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>('ko');
  useEffect(() => {
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : lang;
  }, [lang]);
  const value = useMemo(() => ({ lang, t: STRINGS[lang], setLang }), [lang]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useLang = () => useContext(Ctx);
/** 현재 언어의 문구 묶음 */
export const useT = () => useContext(Ctx).t;
export type { Lang, Strings };
