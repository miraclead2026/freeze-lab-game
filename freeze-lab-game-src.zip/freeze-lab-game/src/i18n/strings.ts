/**
 * 다국어 문구 — 기본 한국어(ko). 인트로 화면에서 English / 中文 선택 가능.
 * 주의: 건강기능식품 기능성 문구 금지 — 모든 언어에서 "영양을 지킨다/보존" 수준의 공정 설명만 사용.
 */
export type Lang = 'ko' | 'en' | 'zh';
export const LANGS: { code: Lang; label: string }[] = [
  { code: 'ko', label: '한국어' },
  { code: 'en', label: 'English' },
  { code: 'zh', label: '中文' },
];

export interface Strings {
  loading: string;
  intro: { kicker: string; title: string; desc: [string, string]; start: string; langLabel: string };
  prologue: { lines: string[]; start: string };
  common: { confirm: string; restart: string; restartConfirm: string; restartCancel: string; muteOn: string; muteOff: string; step: string };
  freeze: {
    kicker: string;
    hook: string;
    title: string;
    guide: string;
    tempNow: string;
    tempTarget: string;
    taps: string;
    doneTitle: string;
    doneLines: [string, string];
  };
  sublimate: {
    kicker: string;
    hook: string;
    title: string;
    guide: string;
    vacuumOn: string;
    frozenTag: string;
    remaining: string;
    remainingUnit: string;
    vacuumRing: string;
    doneTitle: string;
    doneLines: [string, string];
  };
  blend: {
    kicker: string;
    hook: string;
    title: string;
    guide: string;
    dropHere: string;
    counter: string;
    ingredients: Record<'broccoli' | 'carrot' | 'beet' | 'kale', string>;
  };
  story: { lines: string[]; final: [string, string] };
  complete: {
    kicker: string;
    title: string;
    reward: string;
    confirmed: string;
    r1Head: string;
    r1Sub: string;
    packs: Record<'doctorSaladPack' | 'packDaily' | 'packNutrition' | 'packFermented' | 'packProteinGold', string>;
    rouletteTag: string;
    qrHint: string;
    r2HeadKioskA: string;
    r2HeadKioskB: string;
    r2HeadMobile: string;
    r2Max: string;
    r2More: string;
    r2StepsKiosk: [string, string, string];
    r2StepsMobile: [string, string, string];
    rewardBtn: string;
    instaTag: string;
    r3HeadA: string;
    r3HeadB: string;
    r3HeadC: string;
    r3Sub: string;
    perksEyebrow: string;
    perksTitle: string;
    perks: [string, string, string];
    restart: string;
  };
}

const ko: Strings = {
  loading: '연구 장비를 준비하고 있어요',
  intro: {
    kicker: 'FREEZE LAB RESEARCH MISSION',
    title: '동결건조 연구 미션',
    desc: ['브로콜리를 얼리고, 수분을 승화시키고,', '원물을 분쇄해 닥터샐러드를 완성해 보세요.'],
    start: '연구 시작하기',
    langLabel: '언어 선택',
  },
  prologue: {
    lines: [
      '갓 수확한 채소는 시간이 지날수록 영양을 잃어갑니다.',
      '열을 가하면 더 많이 사라지고요.',
      '그래서 연구소는 한 가지 질문에서 시작했습니다.',
      '원물의 영양을, 그대로 지킬 수는 없을까?',
      '답은 동결건조. 얼리고, 수분만 꺼내고, 곱게 갈아내는 것.',
      '지금부터 당신이 연구원입니다. 원물의 영양을 끝까지 지켜주세요.',
    ],
    start: '동결건조 START',
  },
  common: {
    confirm: '확인했어요!',
    restart: '처음부터',
    restartConfirm: '처음 화면으로 돌아갈까요?',
    restartCancel: '계속하기',
    muteOn: '효과음 켜기',
    muteOff: '효과음 끄기',
    step: 'STEP',
  },
  freeze: {
    kicker: 'STEP 01. FREEZE',
    hook: '얼려라!!',
    title: '브로콜리를 얼려주세요',
    guide: '화면을 빠르게 터치해\n원물의 온도를 낮춰주세요!',
    tempNow: '현재 온도',
    tempTarget: '목표 온도',
    taps: '터치',
    doneTitle: '1단계 완료!',
    doneLines: ['원물의 좋은 것을 지키기 위한', '급속 동결이 완료되었습니다.'],
  },
  sublimate: {
    kicker: 'STEP 02. SUBLIMATE',
    hook: '수분을 제거하라!!',
    title: '얼어 있는 수분을 꺼내주세요',
    guide: '영양 구조 속 물방울을 터치한 채로\n바깥 진공 영역까지 끌어다 놓으면 증발합니다!',
    vacuumOn: 'VACUUM ON',
    frozenTag: '❄ 영양 구조 · 동결 상태 -40℃',
    remaining: '남은 물방울',
    remainingUnit: '개',
    vacuumRing: '진공 영역 · 여기로 꺼내면 승화',
    doneTitle: '2단계 완료!',
    doneLines: ['얼어 있던 수분이 승화되어', '원물의 좋은 것만 남았습니다.'],
  },
  blend: {
    kicker: 'STEP 03. BLEND',
    hook: '분쇄하라!!',
    title: '동결건조 원물을 분쇄해주세요',
    guide: '원물을 터치한 채로 분쇄기 투입구까지\n끌어다 놓으면 분쇄되어 닥터샐러드에 담깁니다!',
    dropHere: '여기에 놓기',
    counter: '원물 투입',
    ingredients: { broccoli: '브로콜리', carrot: '당근', beet: '비트', kale: '케일' },
  },
  story: {
    lines: ['원물을 [동결] 하고', '동결된 채로 [수분만 승화] 하고', '[가루]로 만들어'],
    final: ['영양을 유지시킨', '[닥터샐러드]가 완성되었습니다'],
  },
  complete: {
    kicker: 'MISSION COMPLETE!',
    title: '연구 완료! 보상 3가지를 확인하세요',
    reward: 'REWARD',
    confirmed: '확정',
    r1Head: '낱포 1개를 받아가세요!',
    r1Sub: '5종 중 마음에 드는 것 하나, 현장에서 바로 드려요',
    packs: { doctorSaladPack: '닥터샐러드', packDaily: '라이프밀 데일리', packNutrition: '영양식', packFermented: '발효건강식', packProteinGold: '프로틴골드' },
    rouletteTag: '룰렛',
    qrHint: '내 폰 카메라로 스캔',
    r2HeadKioskA: 'QR 찍으면',
    r2HeadKioskB: '더!',
    r2HeadMobile: '룰렛 돌리면',
    r2Max: '최대 5개',
    r2More: '더!',
    r2StepsKiosk: ['QR 스캔', '룰렛 돌리기', '당첨 낱포 현장 수령'],
    r2StepsMobile: ['혜택 받기', '룰렛 돌리기', '당첨 낱포 현장 수령'],
    rewardBtn: '혜택 받으러 가기',
    instaTag: '인스타그램',
    r3HeadA: '팔로우하면',
    r3HeadB: '동결건조 연구원증',
    r3HeadC: '발급!',
    r3Sub: '팔로우 화면을 카운터에 보여주세요. 내 이름으로 바로 만들어 드려요',
    perksEyebrow: 'MEMBER PERKS',
    perksTitle: '이 카드 하나로, 라이프밀 특별 연구원',
    perks: ['WBTI 웰니스 유형 테스트 하면 할인 쿠폰', '다음 이벤트도 카드 QR로 가장 먼저 열려요', '가지고 있는 동안 혜택은 계속 이어집니다'],
    restart: '처음부터 다시 하기',
  },
};

const en: Strings = {
  loading: 'Preparing the lab equipment…',
  intro: {
    kicker: 'FREEZE LAB RESEARCH MISSION',
    title: 'Freeze-Drying Research Mission',
    desc: ['Freeze the broccoli, sublimate the water,', 'grind it down and complete your Dr. Salad.'],
    start: 'Start the Research',
    langLabel: 'Language',
  },
  prologue: {
    lines: [
      'Freshly harvested vegetables lose nutrients as time passes.',
      'Apply heat, and even more slips away.',
      'So the lab began with a single question.',
      'Can we keep the nutrients of raw ingredients just as they are?',
      'The answer: freeze-drying. Freeze it, draw out only the water, grind it fine.',
      'From now on, you are the researcher. Protect the nutrients to the very end.',
    ],
    start: 'START FREEZE-DRYING',
  },
  common: {
    confirm: 'Got it!',
    restart: 'Restart',
    restartConfirm: 'Go back to the start?',
    restartCancel: 'Keep playing',
    muteOn: 'Turn sound on',
    muteOff: 'Turn sound off',
    step: 'STEP',
  },
  freeze: {
    kicker: 'STEP 01. FREEZE',
    hook: 'FREEZE IT!!',
    title: 'Freeze the broccoli',
    guide: 'Tap the screen quickly\nto bring the temperature down!',
    tempNow: 'Current temp',
    tempTarget: 'Target',
    taps: 'Taps',
    doneTitle: 'Step 1 complete!',
    doneLines: ['Rapid freezing is done —', 'the good stuff is locked in.'],
  },
  sublimate: {
    kicker: 'STEP 02. SUBLIMATE',
    hook: 'REMOVE THE WATER!!',
    title: 'Pull out the frozen water',
    guide: 'Press a droplet and drag it out\ninto the vacuum zone to evaporate it!',
    vacuumOn: 'VACUUM ON',
    frozenTag: '❄ Nutrient structure · Frozen at -40℃',
    remaining: 'Droplets left',
    remainingUnit: '',
    vacuumRing: 'Vacuum zone · drop here to sublimate',
    doneTitle: 'Step 2 complete!',
    doneLines: ['The frozen water has sublimated,', 'leaving only the good part of the ingredient.'],
  },
  blend: {
    kicker: 'STEP 03. BLEND',
    hook: 'GRIND IT!!',
    title: 'Grind the freeze-dried ingredients',
    guide: 'Drag an ingredient to the grinder inlet\nto grind it into your Dr. Salad!',
    dropHere: 'Drop here',
    counter: 'Ingredients added',
    ingredients: { broccoli: 'Broccoli', carrot: 'Carrot', beet: 'Beet', kale: 'Kale' },
  },
  story: {
    lines: ['[Freeze] the ingredient,', '[sublimate only the water] while frozen,', 'and turn it into [powder] —'],
    final: ['Nutrients kept intact:', 'your [Dr. Salad] is complete'],
  },
  complete: {
    kicker: 'MISSION COMPLETE!',
    title: 'Research done! Check your 3 rewards',
    reward: 'REWARD',
    confirmed: 'Yours',
    r1Head: 'Take home 1 sample stick!',
    r1Sub: 'Pick any one of the 5 — handed to you right here',
    packs: { doctorSaladPack: 'Dr. Salad', packDaily: 'LIFEMEAL Daily', packNutrition: 'Nutrition', packFermented: 'Fermented', packProteinGold: 'Protein Gold' },
    rouletteTag: 'Roulette',
    qrHint: 'Scan with your phone camera',
    r2HeadKioskA: 'Scan the QR for',
    r2HeadKioskB: 'more!',
    r2HeadMobile: 'Spin the roulette for',
    r2Max: 'up to 5',
    r2More: 'more!',
    r2StepsKiosk: ['Scan QR', 'Spin the roulette', 'Collect your sticks on site'],
    r2StepsMobile: ['Tap "Get rewards"', 'Spin the roulette', 'Collect your sticks on site'],
    rewardBtn: 'Get my rewards',
    instaTag: 'Instagram',
    r3HeadA: 'Follow us, get your',
    r3HeadB: 'Researcher ID card',
    r3HeadC: '',
    r3Sub: 'Show your follow screen at the counter — printed with your name, on the spot',
    perksEyebrow: 'MEMBER PERKS',
    perksTitle: 'Your LIFEMEAL special researcher card',
    perks: ['WBTI wellness test → discount coupon', 'Future events open first via the card QR', 'Perks continue as long as you keep the card'],
    restart: 'Play again from the start',
  },
};

const zh: Strings = {
  loading: '正在准备研究设备…',
  intro: {
    kicker: 'FREEZE LAB RESEARCH MISSION',
    title: '冻干研究任务',
    desc: ['冷冻西兰花，让水分升华，', '再把原料研磨成粉，完成你的 Dr. Salad。'],
    start: '开始研究',
    langLabel: '选择语言',
  },
  prologue: {
    lines: [
      '刚采摘的蔬菜，营养会随着时间慢慢流失。',
      '一旦加热，流失得更多。',
      '于是，研究所从一个问题开始。',
      '能不能把原料的营养，原封不动地留住？',
      '答案是冻干：先冷冻，只抽走水分，再细细研磨。',
      '从现在起，你就是研究员。请把原料的营养守护到最后。',
    ],
    start: '开始冻干 START',
  },
  common: {
    confirm: '我知道了！',
    restart: '回到开头',
    restartConfirm: '要回到开始画面吗？',
    restartCancel: '继续游戏',
    muteOn: '打开音效',
    muteOff: '关闭音效',
    step: 'STEP',
  },
  freeze: {
    kicker: 'STEP 01. FREEZE',
    hook: '冷冻！！',
    title: '请把西兰花冻起来',
    guide: '快速点击屏幕，\n让原料的温度降下来！',
    tempNow: '当前温度',
    tempTarget: '目标温度',
    taps: '点击',
    doneTitle: '第 1 步完成！',
    doneLines: ['为了留住原料的好东西，', '急速冷冻已完成。'],
  },
  sublimate: {
    kicker: 'STEP 02. SUBLIMATE',
    hook: '去除水分！！',
    title: '请把冻住的水分取出来',
    guide: '按住营养结构里的水滴，\n拖到外面的真空区，它就会蒸发！',
    vacuumOn: 'VACUUM ON',
    frozenTag: '❄ 营养结构 · 冷冻状态 -40℃',
    remaining: '剩余水滴',
    remainingUnit: '个',
    vacuumRing: '真空区 · 拖到这里即可升华',
    doneTitle: '第 2 步完成！',
    doneLines: ['冻住的水分已经升华，', '只留下原料的好东西。'],
  },
  blend: {
    kicker: 'STEP 03. BLEND',
    hook: '研磨！！',
    title: '请研磨冻干原料',
    guide: '按住原料拖到研磨机入口，\n研磨后会装进 Dr. Salad！',
    dropHere: '放到这里',
    counter: '原料投入',
    ingredients: { broccoli: '西兰花', carrot: '胡萝卜', beet: '甜菜根', kale: '羽衣甘蓝' },
  },
  story: {
    lines: ['把原料 [冷冻]，', '在冷冻状态下 [只让水分升华]，', '再制成 [粉末] ——'],
    final: ['保留了营养的', '[Dr. Salad] 完成了'],
  },
  complete: {
    kicker: 'MISSION COMPLETE!',
    title: '研究完成！请查看 3 项奖励',
    reward: 'REWARD',
    confirmed: '已确定',
    r1Head: '请领取 1 条试用装！',
    r1Sub: '5 款任选 1 条，现场直接送给你',
    packs: { doctorSaladPack: 'Dr. Salad', packDaily: 'LIFEMEAL Daily', packNutrition: '营养餐', packFermented: '发酵健康餐', packProteinGold: 'Protein Gold' },
    rouletteTag: '转盘',
    qrHint: '用手机相机扫描',
    r2HeadKioskA: '扫码转转盘',
    r2HeadKioskB: '！',
    r2HeadMobile: '转转盘',
    r2Max: '最多再得 5 条',
    r2More: '！',
    r2StepsKiosk: ['扫描二维码', '转动转盘', '现场领取中奖试用装'],
    r2StepsMobile: ['点击"领取福利"', '转动转盘', '现场领取中奖试用装'],
    rewardBtn: '去领取福利',
    instaTag: 'Instagram',
    r3HeadA: '关注即可获得',
    r3HeadB: '冻干研究员证',
    r3HeadC: '！',
    r3Sub: '把关注页面出示给柜台，我们现场为你制作印有你名字的研究员证',
    perksEyebrow: 'MEMBER PERKS',
    perksTitle: '一张卡，成为 LIFEMEAL 特别研究员',
    perks: ['完成 WBTI 健康类型测试可获优惠券', '之后的活动也会通过卡片二维码优先开放', '只要持有这张卡，福利就会持续'],
    restart: '从头再玩一次',
  },
};

export const STRINGS: Record<Lang, Strings> = { ko, en, zh };
