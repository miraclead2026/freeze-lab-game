/// <reference types="vite/client" />

declare module 'virtual:freeze-lab-assets' {
  /** 파일명 → URL(일반 빌드) 또는 data URI(단일 파일 빌드) */
  const assets: Record<string, string>;
  export default assets;
}
