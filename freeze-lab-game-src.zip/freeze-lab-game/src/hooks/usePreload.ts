import { useEffect, useRef, useState } from 'react';
import { ALL_ASSET_KEYS, assetUrl, type AssetKey } from '../config/assets';

export interface PreloadResult {
  progress: number; // 0~1
  ready: boolean;
  failed: Set<AssetKey>;
}

/** 게임 시작 전 모든 이미지 소스를 프리로드합니다. 실패해도 게임은 진행되며 컬러 플레이스홀더로 대체됩니다. */
export function usePreload(): PreloadResult {
  const [progress, setProgress] = useState(0);
  const [ready, setReady] = useState(false);
  const failedRef = useRef<Set<AssetKey>>(new Set());

  useEffect(() => {
    let alive = true;
    let loaded = 0;
    const total = ALL_ASSET_KEYS.length + 1; // +1 폰트
    const bump = () => {
      loaded += 1;
      if (alive) setProgress(loaded / total);
    };

    const imagePromises = ALL_ASSET_KEYS.map(
      (key) =>
        new Promise<void>((resolve) => {
          const img = new Image();
          img.decoding = 'async';
          img.onload = () => {
            bump();
            resolve();
          };
          img.onerror = () => {
            failedRef.current.add(key);
            bump();
            resolve();
          };
          img.src = assetUrl(key);
        }),
    );

    const fontPromise = (document.fonts?.ready ?? Promise.resolve()).then(() => bump());

    Promise.all([...imagePromises, fontPromise]).then(() => {
      if (!alive) return;
      // 최소 노출 시간(로딩 화면이 깜빡이지 않도록)
      setTimeout(() => alive && setReady(true), 350);
    });

    return () => {
      alive = false;
    };
  }, []);

  return { progress, ready, failed: failedRef.current };
}
