# LIFEMEAL FREEZE LAB — 동결건조 연구 미션 (모바일 인터랙티브 게임)

브로콜리를 얼리고(01 FREEZE) → 수분을 승화시키고(02 SUBLIMATE) → 원물을 분쇄해(03 BLEND) 닥터샐러드를 완성하는 3단계 게임.  
React 18 + TypeScript + Vite. 게임 엔진 없이 DOM/SVG + Canvas 파티클로 구현. 390×844 기준, 100dvh, 스크롤 없음.

## 실행 · 빌드

```bash
npm install
npm run dev            # 개발 서버
npm run build          # dist/  → Cloudflare Pages / Vercel / GitHub Pages 등 정적 배포
npm run build:single   # dist-single/index.html → 이미지·폰트 인라인 단일 HTML (미리보기·아티팩트용)
npm run preview        # dist/ 미리보기 (http://localhost:4173)
```

자동 플레이 검수: `node scripts/playtest.mjs http://localhost:4173/ mobile` (mobile | android | tablet | desktop)

## 파일 구조

```
freeze-lab-game/
├─ index.html                      # Pretendard CDN 링크 (차단 시 로컬 서브셋 폰트로 대체)
├─ vite.config.ts                  # 일반/단일 파일 빌드, virtual:freeze-lab-assets 플러그인
├─ public/assets/freeze-lab/       # 이미지 소스 9종 (ASSET_MANIFEST.md 참고)
├─ src/
│  ├─ App.tsx                      # 상태 머신 → 화면 라우팅, 전환 타이머
│  ├─ config/
│  │  ├─ gameConfig.ts             # ★ REWARD_URL, 온도·터치 횟수·물 분자·원물 개수·타이밍·컬러
│  │  ├─ assets.ts                 # ★ 이미지 매니페스트 + 비율 앵커
│  │  └─ layout.ts                 # 390×844 기준 장면 좌표 (렌즈 중심, 분쇄기·낱포·원물 위치)
│  ├─ state/gameMachine.ts         # LOADING → INTRO → STEP_1 … → MISSION_COMPLETE 리듀서
│  ├─ hooks/usePreload.ts          # 전체 소스 프리로드 + 진행률
│  ├─ hooks/useReducedMotion.ts    # prefers-reduced-motion
│  ├─ particles/system.ts          # Canvas 파티클 (ice·mist·vapor·powder·confetti·check·glow·dust)
│  ├─ particles/ParticleCanvas.tsx # 단일 Canvas + rAF 루프 + Context
│  ├─ components/
│  │  ├─ Stage.tsx                 # 논리 캔버스 스케일링 · 좌표 변환
│  │  ├─ ui/ProgressHeader.tsx     # 01 FREEZE → 02 SUBLIMATE → 03 BLEND + 진행률
│  │  ├─ ui/StepBriefing.tsx       # 단계 시작 1.5초 안내 + 손가락 가이드
│  │  ├─ ui/SuccessPopup.tsx       # 완료 팝업 (1.4초 노출 + 1초 결과 확인 후 자동 전환)
│  │  ├─ ui/QRCodeBlock.tsx        # ★ QR 독립 컴포넌트 (URL/PNG 교체)
│  │  ├─ ui/SafeImage.tsx          # 로딩 실패 시 컬러 플레이스홀더
│  │  ├─ ui/FingerGuide.tsx
│  │  └─ steps/  Loading · Intro · FreezeStep · MicroscopeStep · GrinderStep · StoryScreen · CompleteScreen
│  └─ styles/global.css
├─ scripts/playtest.mjs            # Playwright 자동 플레이 검수
├─ ASSET_MANIFEST.md
└─ raw/                            # AI 생성 원본 PNG (배포 불필요)
```

## 교체가 필요한 소스 (★)

1. **QR URL** — `src/config/gameConfig.ts` → `REWARD_URL` (현재 `https://omopl.com/sh/9cecac74` OMO PLAY 룰렛 이벤트)  
   QR과 "룰렛 돌리러 가기" 버튼(새 창) 모두 이 상수를 씁니다. 완성된 QR PNG를 쓰려면 `CompleteScreen.tsx`의 `<QRCodeBlock imageSrc="..." />`에 경로를 넘기면 됩니다. 비어 있으면 "QR URL 입력 필요" 플레이스홀더가 표시됩니다.
2. (선택) 인트로 문구 — `src/components/steps/IntroScreen.tsx`
3. (선택) 제품 이미지 교체 — `public/assets/freeze-lab/doctor-salad-pack.png`(완제품), `doctor-salad-pack-open.png`(뜯어진 버전), `pack-*.png`(라인업 4종). 같은 파일명으로 덮어쓰면 됩니다. 뜯어진 버전의 입구 위치는 `src/config/assets.ts` → `doctorSaladPackOpen.anchors.mouth`, 크기는 `src/config/layout.ts` → `PACK_BOX`.
4. (선택) 효과음 — `src/audio/sfx.ts`에서 Web Audio로 합성합니다. 음원 파일로 바꾸려면 각 메서드 안을 `new Audio(url).play()`로 교체하면 됩니다. 우측 상단 스피커 버튼으로 끄기/켜기(localStorage에 기억).

## 게임 밸런스 상수 (`src/config/gameConfig.ts`)

| 항목 | 값 |
|---|---|
| 시작/목표 온도 | 20℃ / -40℃ |
| 터치 횟수 | 15회 (1회당 4℃) |
| 물 분자 개수 | 8개 |
| 원물 개수 | 4종 (브로콜리·당근·비트·케일) |
| 브리핑 노출 | 1.5초 |
| 완료 팝업 | 1.4초 + 결과 확인 1초 |
| 줌인 / 줌아웃 / 최종 확대 | 1.9초 / 1.5초 / 1.2초 |
| 파티클 상한 | 420 (reduced-motion 120) |

총 플레이 시간 약 40~60초 (자동 검수 기준 약 37~45초 + 사용자 반응 시간).

## 2차 수정 반영 (2026-09-02)

- 인트로: 라이프밀 로고(메인) + 그 아래 Freeze Lab 로고
- 단계 안내: 자동 시작 대신 **"확인했어요!"** 버튼을 눌러 시작
- STEP 2: 얼어 있는 벌집형 영양 구조 배경 + 누가 봐도 물인 **물방울** 8개. 물방울을 터치한 채로 렌즈 바깥 **진공 영역**까지 끌어다 놓으면 승화(안쪽에 놓으면 제자리로 복귀)
- STEP 3: 원물을 **분쇄기 투입구로 드래그**해 놓아야 투입(드롭 존 표시, 벗어나면 복귀). 실제 닥터샐러드 낱포를 사용하며 분말을 받는 동안은 **윗부분이 뜯어진 버전**, 4종 완료 시 밀봉된 완제품으로 크로스페이드
- MISSION COMPLETE: 닥터샐러드가 올라온 뒤 낱포 5종(라이프밀 데일리 · 영양식 · 닥터샐러드 · 발효건강식 · 프로틴골드) 라인업이 구성되고 "원하는 1포를 현장에서 받아가세요" 안내
- MISSION STORY(완료 화면 직전): "원물을 [동결] 하고 → 동결된 채로 [수분만 승화] 하고 → [가루]로 만들어 → 영양을 유지시킨 [닥터샐러드]가 완성되었습니다" 문장이 하나씩 올라온 뒤 완료 화면으로 이동. 문구는 `src/components/steps/StoryScreen.tsx`의 `STORY_LINES` / `STORY_FINAL`에서 수정 (대괄호 = 강조)
- MISSION COMPLETE v3 (QR 전환 목적): 헤드라인 "연구 완료! 낱포 1포 확정 / 룰렛 돌리고 최대 5포까지 더 받아 가세요" + 서브 "카카오 로그인 10초면 끝…" → "낱포 1포 확정" 배지 → 낱포 5종 라인업 → QR(화면 폭 40%, 흰 배경, quiet zone 2모듈) + "QR 찍고 룰렛 돌리기 / 지금 찍으면 바로 참여 / 최대 5포" → "룰렛 돌리러 가기" 버튼(본인 폰 플레이용, 새 창) → 면허증 3단계 칩(01 완료 ✓ · 02 룰렛 ← 지금 · 03 인스타 팔로우, 링크 없음) → "발급까지 1단계 남음" → 보조 안내 → 다시 하기(작은 텍스트). QR은 본문보다 0.5초 늦게 효과음과 함께 등장하고, QR 위로는 파티클을 뿌리지 않습니다. 문구 전체는 `CompleteScreen.tsx`에 있습니다.
- 효과음: 버튼, 터치 결빙, 결정 버스트, 줌, 물방울 집기/이동/복귀/승화, 원물 집기/투입, 분쇄기 대기·작동 험, 분말, 단계 완료 차임, 미션 완료 팡파르, 제품 등장 등 전 구간

## 동작 메모

- 단계 전환은 모두 같은 페이지 안에서 상태 변경으로 진행됩니다 (URL 이동·새로고침 없음).
- 브로콜리 줌인과 현미경 렌즈는 `LENS_CENTER (195, 420)`를 공유합니다. 줌아웃은 STEP 3 브로콜리 카드 위치로 착지하며, 같은 `fd-broccoli.webp`를 사용합니다.
- 분말은 분쇄기 `outlet` 앵커에서 생성돼 낱포 `mouth` 앵커에서 제거됩니다. 이미지 크기가 바뀌어도 비율 앵커로 좌표가 유지됩니다.
- 모든 터치 영역은 56px 이상 (원물 카드 84px, 물 분자 64px, 브로콜리 350px 원형).
- 입력 잠금: 마지막 터치 이후, 원물 이동 중, 터치된 물 분자 등은 즉시 비활성화되어 중복 실행되지 않습니다.
- `prefers-reduced-motion`: 줌 배율·시간, 파티클 수를 줄입니다.
- 이미지 로딩 실패 시 `SafeImage`가 컬러 플레이스홀더를 표시합니다.
- 폰트: Pretendard Variable (CDN 동적 서브셋) → 차단 시 번들된 로컬 서브셋(KS X 1001 한글 2,350자) → 시스템 폰트 순으로 대체.

## 배포

`npm run build` 후 `dist/`를 정적 호스팅에 올리면 됩니다. `base: './'`라 하위 경로 배포도 가능합니다.
