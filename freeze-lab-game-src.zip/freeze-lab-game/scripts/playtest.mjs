/**
 * 자동 플레이 검수 스크립트 — Playwright로 실제 게임을 처음부터 끝까지 플레이합니다.
 * 사용: node scripts/playtest.mjs [url] [viewport]  (viewport: mobile | tablet | desktop)
 */
import { chromium, devices } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import fs from 'node:fs';

const url = process.argv[2] ?? 'http://127.0.0.1:4173/';
const vp = process.argv[3] ?? 'mobile';
const outDir = `shots/${vp}`;
fs.mkdirSync(outDir, { recursive: true });

const viewports = {
  mobile: { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  kiosk: { viewport: { width: 540, height: 960 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  android: { viewport: { width: 360, height: 780 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true },
  tablet: { viewport: { width: 820, height: 1180 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  desktop: { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
};

const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
const context = await browser.newContext({ ...viewports[vp], ...(vp === 'mobile' ? { userAgent: devices['iPhone 13'].userAgent } : {}) });
const page = await context.newPage();
await page.addInitScript(() => {
  window.__sfx = [];
  const os = AudioBufferSourceNode.prototype.start;
  AudioBufferSourceNode.prototype.start = function (...a) {
    if (this.buffer && this.buffer.duration > 0.5 && this.buffer.duration < 3) window.__sfx.push(`${this.buffer.duration.toFixed(2)}s@${(performance.now() / 1000).toFixed(1)}`);
    return os.apply(this, a);
  };
});
// 클라우드 환경에서 CDN 접근 불가 → 배경 이미지를 로컬 플레이스홀더로 대체 (레이아웃 검수용)
const PLACEHOLDER = fs.readFileSync(process.env.BG_PLACEHOLDER ?? '/tmp/claude-0/src/placeholder.png');
await page.route('**/*.cloudfront.net/**', (route) => route.fulfill({ status: 200, contentType: 'image/png', body: PLACEHOLDER }));
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));

const t0 = Date.now();
const log = (msg) => console.log(`[${((Date.now() - t0) / 1000).toFixed(1)}s] ${msg}`);
const shot = (name) => page.screenshot({ path: `${outDir}/${name}.png` });

// 스테이지 논리 좌표 → 클라이언트 좌표
async function stagePoint(x, y) {
  return page.evaluate(
    ([x, y]) => {
      const st = document.querySelector('.stage');
      const r = st.getBoundingClientRect();
      const s = r.height / 844;
      const off = (st.offsetWidth - 390) / 2; // 키오스크(474폭)는 390 기준 좌표를 가운데로
      return { x: r.left + (x + off) * s, y: r.top + y * s };
    },
    [x, y],
  );
}
async function tapStage(x, y) {
  const p = await stagePoint(x, y);
  if (viewports[vp].hasTouch) await page.touchscreen.tap(p.x, p.y);
  else await page.mouse.click(p.x, p.y);
}

await page.goto(url, { waitUntil: 'networkidle' });
log('loaded');
await shot('00-loading');
await page.waitForSelector('.intro', { timeout: 15000 });
await shot('01-intro');
// 언어 선택: English → 中文 → 한국어(기본)
for (const [label, name] of [['English', '01-intro-en'], ['中文', '01-intro-zh']]) {
  await page.click(`.lang-btn:has-text("${label}")`);
  await page.waitForTimeout(300);
  await shot(name);
  log(`언어 ${label}: ${await page.locator('.intro h1').textContent()}`);
}
await page.click(`.lang-btn:has-text("${process.env.GAME_LANG ?? '한국어'}")`);
await page.waitForTimeout(200);
log('INTRO 표시');
await page.click('.intro .btn');
// PROLOGUE — 원물 눈송이 + 문장 순차 등장 → 동결건조 START
await page.waitForSelector('.prologue', { timeout: 5000 });
await page.waitForTimeout(3200);
await shot('01b-prologue-mid');
await page.waitForSelector('.prologue-btn.show', { timeout: 12000 });
await page.waitForTimeout(400);
await shot('01c-prologue-ready');
log(`PROLOGUE 문장 ${await page.locator('.prologue-line.show').count()}/6 표시 → START`);
await page.click('.prologue-btn');

async function confirmBriefing(name) {
  await page.waitForSelector('.briefing-live', { timeout: 8000 });
  await page.waitForTimeout(1200);
  if (name) await shot(name);
  const early = await page.locator('.briefing-btn.show').count();
  await page.waitForSelector('.briefing-btn.show', { timeout: 8000 });
  log(`브리핑 확인 버튼: 1.2초 시점 ${early ? '이미 표시(오류)' : '숨김'} → 3초 뒤 표시`);
  await page.click('.briefing-btn');
  await page.waitForSelector('.briefing', { state: 'detached', timeout: 5000 });
}
async function dragTo(locator, tx, ty, steps = 12) {
  const box = await locator.boundingBox();
  const sx = box.x + box.width / 2;
  const sy = box.y + box.height / 2;
  await page.mouse.move(sx, sy);
  await page.mouse.down();
  for (let i = 1; i <= steps; i++) {
    await page.mouse.move(sx + ((tx - sx) * i) / steps, sy + ((ty - sy) * i) / steps);
    await page.waitForTimeout(16);
  }
  await page.mouse.up();
}

// 상단 "처음부터" 버튼 — 팝오버 열고 취소
await page.click('.restart-btn');
await page.waitForSelector('.restart-pop', { timeout: 3000 });
await page.click('.restart-pop .no');
log('처음부터 버튼: 팝오버 열림/취소 OK');
// STEP 1
await confirmBriefing('02-step1-briefing');
log('STEP 1 시작 (확인했어요 버튼)');
const tapZone = page.locator('.tap-zone');
await tapZone.waitFor();
for (let i = 0; i < 15; i++) {
  await tapStage(195 + (i % 3) * 40 - 40, 420 + (i % 2) * 30);
  await page.waitForTimeout(110);
  if (i === 6) await shot('03-step1-mid');
}
await page.waitForSelector('.popup', { timeout: 5000 });
const t1 = await page.locator('.popup h3').textContent();
log(`STEP 1 완료 팝업: ${t1}`);
await shot('04-step1-complete');
await page.waitForSelector('.popup', { state: 'detached', timeout: 6000 });
await page.waitForTimeout(900);
await shot('05-zoom-in');

// STEP 2 — 물방울을 렌즈 밖으로 드래그
await page.waitForSelector('.vacuum-tag', { timeout: 8000 });
await confirmBriefing('05b-step2-briefing');
log('STEP 2 시작');
await page.waitForTimeout(1600);
await shot('06-step2');
const lensC = await stagePoint(195, 420);
const dropCount = await page.locator('.droplet-btn').count();
log(`물방울 ${dropCount}개`);
for (let i = 0; i < dropCount; i++) {
  const btn = page.locator('.droplet-btn:not([disabled])').first();
  await btn.waitFor({ timeout: 5000 });
  const box = await btn.boundingBox();
  const cx = box.x + box.width / 2, cy = box.y + box.height / 2;
  const ang = Math.atan2(cy - lensC.y, cx - lensC.x);
  const s = (await page.evaluate(() => document.querySelector('.stage').getBoundingClientRect().height / 844));
  const tx = lensC.x + Math.cos(ang) * 205 * s, ty = lensC.y + Math.sin(ang) * 205 * s;
  if (i === 2) { // 실패 케이스: 안쪽에 놓으면 제자리로
    await dragTo(btn, lensC.x + Math.cos(ang) * 60 * s, lensC.y + Math.sin(ang) * 60 * s, 6);
    await page.waitForTimeout(400);
    const left = await page.locator('.droplet-btn').count();
    log(`안쪽에 놓기 → 제자리 복귀 (물방울 ${left}개 유지)`);
  }
  await dragTo(btn, tx, ty);
  await page.waitForTimeout(220);
  if (i === 2) await shot('07-step2-mid');
}
await page.waitForSelector('.popup', { timeout: 8000 });
const t2 = await page.locator('.popup h3').textContent();
log(`STEP 2 완료 팝업: ${t2}`);
await shot('08-step2-complete');
await page.waitForSelector('.popup', { state: 'detached', timeout: 6000 });
await page.waitForTimeout(700);
await shot('09-zoom-out');

// STEP 3 — 원물을 투입구로 드래그
await page.waitForSelector('.blend-counter', { timeout: 8000 });
await confirmBriefing('09b-step3-briefing');
log('STEP 3 시작');
await shot('10-step3');
const intake = await stagePoint(-5 + 400 * 0.5, 292 + 400 * 0.13);
for (let i = 0; i < 4; i++) {
  const btn = page.locator('.ingredient:not([disabled])').first();
  await btn.waitFor({ timeout: 8000 });
  if (i === 1) { // 실패 케이스: 엉뚱한 곳에 놓기
    const wrong = await stagePoint(60, 480);
    await dragTo(btn, wrong.x, wrong.y, 6);
    await page.waitForTimeout(400);
    log(`엉뚱한 곳에 놓기 → 제자리 복귀 (카운터 ${await page.locator('.blend-counter').textContent()})`);
  }
  await dragTo(btn, intake.x, intake.y);
  await page.waitForTimeout(500);
  if (i === 0) await shot('11-step3-drop');
  await page.waitForTimeout(700);
  if (i === 1) await shot('12-step3-powder');
  await page.waitForTimeout(500);
}
const counter = await page.locator('.blend-counter').textContent().catch(() => 'n/a');
log(`원물 투입 카운터: ${counter}`);
await page.waitForSelector('.story', { timeout: 14000 });
log('MISSION STORY (문장 등장)');
await page.waitForTimeout(3200);
await shot('12b-story');
await page.waitForTimeout(1500);
await shot('12c-story-final');
await page.waitForSelector('.complete', { timeout: 14000 });
log('MISSION COMPLETE');
await page.waitForTimeout(500);
await shot('13-complete-rise');
await page.waitForTimeout(2400);
await shot('14-complete-lineup');
const packs = await page.locator('.lineup-item.show').count();
log(`라인업 낱포 ${packs}종 표시`);
await page.waitForTimeout(600);
await shot('15-complete-qr');
await page.waitForSelector('.rw-card.rw3.show', { timeout: 6000 });
await page.waitForTimeout(700);
await shot('16-complete-rewards');
const qr = await page.locator('.qr-frame canvas').count();
const rewardHref = await page.locator('.reward-btn').getAttribute('href').catch(() => null);
log(`모드 ${await page.evaluate(() => document.documentElement.dataset.mode)} · QR ${qr ? 'OK' : '없음'} · 혜택 버튼 ${rewardHref ?? '없음'} · 보상 카드 ${await page.locator('.rw-card.show').count()}/3`);
await page.click('.restart-link');
await page.waitForSelector('.intro', { timeout: 5000 });
log('다시 하기 → INTRO 복귀 OK');
log(`녹음 음성 재생: ${JSON.stringify(await page.evaluate(() => window.__sfx))}`);
log(`총 소요: ${((Date.now() - t0) / 1000).toFixed(1)}s, 콘솔 오류 ${errors.length}건`);
errors.forEach((e) => console.log('  ERROR:', e));
await browser.close();
