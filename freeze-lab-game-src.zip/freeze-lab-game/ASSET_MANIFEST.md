# FREEZE LAB 게임 — Asset Manifest

경로: `public/assets/freeze-lab/`  
코드 매핑: `src/config/assets.ts` (파일명·앵커·플레이스홀더 색상)

| # | 파일명 | 크기 | 용량 | 생성 방식 | 사용 위치 | 코드 합성 효과 |
|---|---|---|---|---|---|---|
| 01 | `broccoli-fresh.webp` | 1024×1024, 투명 | 179 KB | AI 생성(Nano Banana Pro) → 배경 제거 | STEP 1 브로콜리 · 인트로 · 줌인 전환 | CSS filter(채도↓·밝기↑·hue-rotate)로 냉동 색상 변화, frost 오버레이 마스크, 줌인 scale 7× |
| 02 | `frost-texture.webp` | 1024×1024, 투명(luminance→alpha) | 403 KB | AI 생성(검정 배경) → 밝기를 알파로 변환 | STEP 1 브로콜리 성에 오버레이(브로콜리 형태 마스크) · 가장자리 성에 · 화면 테두리 서리 | 진행률에 따라 opacity 0→0.95, mix-blend screen |
| 02 | `frost-tile.webp` | 512×512, 투명 | 44 KB | frost-texture 모서리 결정 영역을 미러 타일링해 만든 이음새 없는 타일(알파 강화) | STEP 1 브로콜리 표면 성에(브로콜리 알파 마스크 · 2겹 반복) · 윤곽 성에 띠(확대 마스크 − 원본 마스크) | 진행률에 따라 opacity 증가 |
| 03 | `microscope-tissue.webp` | 1536×2048 | 252 KB | AI 생성(2K, 얼어 있는 벌집형 세포 구조) → 리사이즈 | STEP 2 현미경 배경 · 줌인/줌아웃 전환 렌즈 내부 | 원형 마스크(`.lens-mask`) + 성에 오버레이, 물방울은 별도 SVG(드래그) |
| 04 | `fd-broccoli.webp` | 768×768, 투명 | 49 KB | 2×2 세트 1장 생성 → 배경 제거 → 사분면 분할(동일 스케일) | STEP 2→3 줌아웃 착지 · STEP 3 원물 카드 | 곡선 이동 → 투입구에서 축소 소멸 |
| 04 | `fd-carrot.webp` | 768×768, 투명 | 44 KB | 〃 | STEP 3 원물 카드 | 〃 · 주황 분말 |
| 04 | `fd-beet.webp` | 768×768, 투명 | 67 KB | 〃 | STEP 3 원물 카드 | 〃 · 붉은 자주 분말 |
| 04 | `fd-kale.webp` | 768×768, 투명 | 67 KB | 〃 | STEP 3 원물 카드 | 〃 · 진한 녹색 분말 |
| 05 | `grinder-base.webp` | 1200×1200, 투명 | 32 KB | AI 생성 → 배경 제거 | STEP 3 분쇄기 본체 | 호퍼 안 회전 날(SVG), 진동(CSS shake), 작동 표시등, 분말 Canvas |
| 06 | `doctor-salad-pack.png` | 156×640, 투명 | 153 KB | **실제 제품 촬영본** 배경 제거(rembg) — 글자·로고 변형 없음 | STEP 3 밀봉 완료 크로스페이드 · MISSION COMPLETE 라인업(중앙) | 최종 확대 zoom, 라인업 이동, 컨페티 |
| 06 | `doctor-salad-pack-open.png` | 156×559, 투명 | 133 KB | 위 이미지를 절취선(✂ 점선) 바로 아래에서 톱니 모양으로 잘라낸 파생본 | STEP 3 배출구 아래 낱포 — 뜯어진 입구로 분말이 들어감 | 분말 소멸점 = `mouth` 앵커 |
| 07 | `pack-lifemeal-daily.png` | 246×640, 투명 | 197 KB | 실제 제품 촬영본 배경 제거 | MISSION COMPLETE 라인업 | 순차 등장 |
| 07 | `pack-nutrition.png` | 231×640, 투명 | 204 KB | 〃 | 〃 | 〃 |
| 07 | `pack-fermented.png` | 247×640, 투명 | 278 KB | 〃 | 〃 | 〃 |
| 07 | `pack-protein-gold.png` | 253×640, 투명 | 219 KB | 〃 | 〃 | 〃 |
| 08 | `logo-lifemeal.png` | 900×192, 투명 | 26 KB | 제공된 로고 원본 축소 | 인트로 메인 로고 | — |
| 08 | `logo-freezelab.png` | 900×401, 투명 | 31 KB | 제공된 로고 원본 여백 제거·축소 | 인트로 서브 로고 (라이프밀 아래) | — |

## 앵커 포인트 (이미지 폭·높이 대비 비율)

| 이미지 | 앵커 | 값 | 의미 |
|---|---|---|---|
| grinder-base | `intake` | (0.50, 0.13) | 상단 투입구 — 원물 이동 도착점 |
| grinder-base | `blade` | (0.50, 0.17) | 회전 날 위치 |
| grinder-base | `outlet` | (0.36, 0.72) | 하단 배출구 — 분말 생성점 |
| grinder-base | `light` | (0.64, 0.83) | 작동 표시등 |
| doctor-salad-pack-open | `mouth` | (0.50, 0.03) | 뜯어진 낱포 입구 — 분말 소멸점 |

이미지를 교체하면 `src/config/assets.ts`의 앵커 값만 새 이미지 기준으로 조정하면 됩니다. 화면 좌표는 `src/config/layout.ts`에서 비율 앵커 → 절대 좌표로 변환됩니다.

## 코드로만 만든 요소 (이미지 없음)

온도 게이지, 진행 상태 바, 손가락 가이드(터치/드래그), 얼음 결정 파티클, 냉기·백연, 브로콜리 색상 변화, 물방울 SVG(드래그·반짝임·복귀), 진공 영역 링, 수증기, 현미경 원형 마스크, 분쇄기 회전 날·진동·작동 불빛·드롭 존, 원물 드래그/투입/복귀 애니메이션, 원물별 분말 파티클, 밀봉 크로스페이드, 낱포 라인업 등장, 단계 완료 팝업, 체크 아이콘, 컨페티, QR 영역 UI, **효과음 전체(Web Audio 합성 — 오디오 파일 없음, `src/audio/sfx.ts`)**.

## 원본 생성 기록

- 모델: Higgsfield · Nano Banana Pro (1K / 현미경 배경 2K), 배경 제거: Higgsfield Background Remover
- 동결건조 4종은 한 장의 2×2 그리드로 생성해 스타일·조명·시점을 통일한 뒤 분할했습니다 (동일 스케일 적용).
- 원본 PNG는 `raw/`에 보관돼 있습니다 (배포에는 포함하지 않아도 됩니다).
